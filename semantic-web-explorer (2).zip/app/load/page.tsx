"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useRdfStore } from "@/lib/rdf-store"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, Download, Info, Network } from "lucide-react"
import { NodeCbdView } from "@/components/node-cbd-view"
import { NodeDetails } from "@/components/node-details"
import { Badge } from "@/components/ui/badge"
import { exportAsDot, exportAsGraphML } from "@/lib/export-utils"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function NodeExplorer() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const { graph, getNodeCBD, setSelectedNode, cbd } = useRdfStore()
  const [graphData, setGraphData] = useState({ nodes: [], links: [] })
  const [isLoading, setIsLoading] = useState(true)

  // Décoder l'ID du nœud depuis l'URL
  const nodeId = params.nodeId ? decodeURIComponent(params.nodeId as string) : null

  useEffect(() => {
    if (!nodeId || !graph) {
      router.push("/")
      return
    }

    setIsLoading(true)

    // Définir le nœud sélectionné et récupérer sa CBD
    setSelectedNode(nodeId)
    getNodeCBD(nodeId)

    setIsLoading(false)
  }, [nodeId, graph, router, setSelectedNode, getNodeCBD])

  // Fonction pour exporter le graphe CBD
  const handleExportCbd = (format) => {
    if (!cbd || cbd.length === 0) {
      toast({
        title: "Aucune donnée CBD",
        description: "Il n'y a aucune donnée CBD à exporter pour ce nœud.",
        variant: "destructive",
      })
      return
    }

    try {
      // Convertir la CBD en format pour l'exportation
      const nodes = new Map()
      const links = []

      // Ajouter le nœud central
      nodes.set(nodeId, {
        id: nodeId,
        name: nodeId.split("/").pop() || nodeId.split("#").pop() || nodeId,
        color: "#7209b7", // Violet pour le nœud central
        size: 15,
      })

      // Parcourir tous les quads de la CBD
      cbd.forEach((quad) => {
        // Ajouter le nœud objet s'il n'existe pas déjà et si c'est une URI
        if (quad.object.termType === "NamedNode" && !nodes.has(quad.object.value)) {
          nodes.set(quad.object.value, {
            id: quad.object.value,
            name: quad.object.value.split("/").pop() || quad.object.value.split("#").pop() || quad.object.value,
            color: "#4361ee", // Bleu pour les objets
            size: 8,
          })
        } else if (quad.object.termType === "Literal" && !nodes.has(`lit_${quad.object.value}`)) {
          // Ajouter les littéraux avec un identifiant unique
          const litId = `lit_${quad.object.value}`
          nodes.set(litId, {
            id: litId,
            name: quad.object.value,
            color: "#f72585", // Rose pour les littéraux
            size: 6,
          })
        }

        // Ajouter un lien
        const targetId = quad.object.termType === "NamedNode" ? quad.object.value : `lit_${quad.object.value}`
        links.push({
          source: quad.subject.value,
          target: targetId,
          name: quad.predicate.value.split("/").pop() || quad.predicate.value.split("#").pop() || quad.predicate.value,
        })
      })

      const cbdGraphData = {
        nodes: Array.from(nodes.values()),
        links: links,
      }

      switch (format) {
        case "dot":
          exportAsDot(cbdGraphData, `node-cbd-${nodeId.split("/").pop() || nodeId.split("#").pop() || "node"}.dot`)
          break
        case "graphml":
          exportAsGraphML(
            cbdGraphData,
            `node-cbd-${nodeId.split("/").pop() || nodeId.split("#").pop() || "node"}.graphml`,
          )
          break
        default:
          throw new Error(`Format d'exportation de graphe non pris en charge: ${format}`)
      }

      toast({
        title: "Exportation réussie",
        description: `La CBD du nœud a été exportée au format ${format.toUpperCase()}.`,
      })
    } catch (error) {
      console.error("CBD export error:", error)
      toast({
        title: "Erreur d'exportation",
        description: error.message || "Une erreur s'est produite lors de l'exportation de la CBD.",
        variant: "destructive",
      })
    }
  }

  // Fonction pour mettre à jour les données du graphe
  const updateGraphData = (data) => {
    setGraphData(data)
  }

  const nodeName = nodeId ? nodeId.split("/").pop() || nodeId.split("#").pop() || nodeId : "Nœud inconnu"

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour
          </Button>
          <h1 className="text-3xl font-bold">Explorateur de Nœud</h1>
          <Badge className="ml-2 bg-semantic-purple text-white">
            <Info className="h-3 w-3 mr-1" />
            {nodeName}
          </Badge>
        </div>

        {cbd && cbd.length > 0 && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Exporter la CBD
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => handleExportCbd("dot")}>
                <span>Exporter en DOT (Graphviz)</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportCbd("graphml")}>
                <span>Exporter en GraphML</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl font-bold flex items-center">
                <Network className="h-6 w-6 mr-2" />
                Visualisation de la CBD
              </CardTitle>
              <CardDescription>Description Concise Bornée (CBD) du nœud sélectionné</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center h-[400px] bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <div className="h-8 w-8 rounded-full border-4 border-semantic-purple border-t-transparent animate-spin"></div>
                </div>
              ) : (
                <NodeCbdView nodeId={nodeId} onGraphDataUpdate={updateGraphData} />
              )}
            </CardContent>
          </Card>
        </div>

        <div>
          <NodeDetails />
        </div>
      </div>
    </div>
  )
}
