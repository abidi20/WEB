"use client"

import { create } from "zustand"
import { Parser, Store, DataFactory, type Quad } from "n3"
import { useBrowser } from "@/hooks/use-browser"

// Define the RDF store state
interface RdfState {
  graph: Store | null
  reasoner: any | null
  selectedNode: string | null
  cbd: Quad[] | null
  currentEndpoint: string | null

  // Actions
  loadRdfFromFile: (file: File, format: string) => Promise<void>
  loadOntology: (file: File) => Promise<void>
  executeQuery: (query: string, useReasoning: boolean) => Promise<any>
  connectToEndpoint: (endpointUrl: string, useCorsProxy?: boolean) => Promise<void>
  disconnectEndpoint: () => void // Nouvelle fonction pour se déconnecter
  setSelectedNode: (nodeUri: string | null) => void
  getNodeCBD: (nodeUri: string) => void
  clearGraph: () => void // Nouvelle fonction pour effacer le graphe
}

export const useRdfStore = create<RdfState>((set, get) => ({
  graph: null,
  reasoner: null,
  selectedNode: null,
  cbd: null,
  currentEndpoint: null,

  loadRdfFromFile: async (file, format) => {
    return new Promise<void>((resolve, reject) => {
      const reader = new FileReader()

      reader.onload = async (event) => {
        try {
          const content = event.target?.result as string
          const parser = new Parser({ format: format })

          // Parse the RDF content
          const quads: Quad[] = []
          parser.parse(content, (error, quad, prefixes) => {
            if (error) {
              reject(new Error(`Error parsing RDF: ${error.message}`))
              return
            }

            if (quad) {
              quads.push(quad)
            } else {
              // End of parsing
              const store = new Store(quads)
              // Ajouter les préfixes communs et données d'exemple
              addCommonPrefixes(store)
              set({ graph: store })
              console.log(`Loaded ${quads.length} quads into the graph (plus common prefixes)`)
              resolve()
            }
          })
        } catch (error) {
          console.error("Error loading RDF:", error)
          reject(new Error(`Error loading RDF: ${error.message}`))
        }
      }

      reader.onerror = () => {
        reject(new Error("Error reading file"))
      }

      reader.readAsText(file)
    })
  },

  loadOntology: async (file) => {
    // In a real implementation, this would load the ontology into a reasoner
    // For this example, we'll just parse it as RDF and store it
    return get().loadRdfFromFile(file, "turtle")
  },

  executeQuery: async (query, useReasoning) => {
    const { graph, currentEndpoint } = get()
    console.log("Execute query called with:", { graph: !!graph, currentEndpoint, query })

    // Déterminer le type de requête SPARQL (de manière plus flexible)
    const queryType = getQueryType(query)
    console.log("Detected query type:", queryType)

    // Vérifier si la requête contient des préfixes FOAF
    const hasFoafPrefix = query.includes("PREFIX foaf:") || query.includes("prefix foaf:")
    const hasFoafPattern = query.toLowerCase().includes("foaf:person") || query.toLowerCase().includes("foaf:name")

    if (currentEndpoint) {
      // Execute query against remote endpoint
      try {
        console.log("Executing query against endpoint:", currentEndpoint)

        // Vérifier si nous sommes dans un environnement navigateur
        if (typeof window === "undefined") {
          throw new Error("Cannot execute query on server-side. Please try again on the client.")
        }

        // Utiliser un proxy CORS si nécessaire
        const corsProxy = "" // Laisser vide pour ne pas utiliser de proxy
        const endpointUrl = corsProxy ? `${corsProxy}${encodeURIComponent(currentEndpoint)}` : currentEndpoint

        // Essayer d'abord avec GET car c'est plus compatible avec la plupart des endpoints
        try {
          console.log("Trying GET request to endpoint")

          // Construire l'URL avec le paramètre 'query=' qui est standard pour les endpoints SPARQL
          // Utiliser encodeURIComponent pour s'assurer que la requête est correctement encodée
          const queryParam = encodeURIComponent(query)
          const getUrl = `${endpointUrl}?query=${queryParam}`

          console.log("GET URL:", getUrl)

          // Définir les en-têtes en fonction du type de requête
          const headers = {
            Accept: getAcceptHeaderForQueryType(queryType),
          }

          console.log("Using headers for GET:", headers)

          const getResponse = await fetch(getUrl, {
            method: "GET",
            headers: headers,
            mode: "cors",
            credentials: "omit",
          })

          if (!getResponse.ok) {
            const errorText = await getResponse.text()
            console.error("GET request error response:", errorText)
            throw new Error(
              `HTTP GET error! status: ${getResponse.status} - ${getResponse.statusText}\nDetails: ${errorText.substring(0, 200)}...`,
            )
          }

          // Traiter la réponse en fonction du type de requête
          return await processResponse(getResponse, queryType)
        } catch (getError) {
          console.warn("GET request failed, trying POST request:", getError)

          // Si GET échoue, essayons avec POST
          try {
            console.log("Trying POST request to endpoint")

            // Pour certains endpoints, le format de la requête POST est différent
            // Certains attendent la requête dans le corps, d'autres comme un paramètre form-urlencoded

            // Méthode 1: Envoi direct dans le corps
            const response = await fetch(endpointUrl, {
              method: "POST",
              headers: {
                "Content-Type": "application/sparql-query",
                Accept: getAcceptHeaderForQueryType(queryType),
              },
              body: query,
              mode: "cors",
              credentials: "omit",
            })

            if (!response.ok) {
              // Si la première méthode échoue, essayons la méthode form-urlencoded
              console.warn("Direct POST failed, trying form-urlencoded")

              const formData = new URLSearchParams()
              formData.append("query", query)

              const formResponse = await fetch(endpointUrl, {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-www-form-urlencoded",
                  Accept: getAcceptHeaderForQueryType(queryType),
                },
                body: formData.toString(),
                mode: "cors",
                credentials: "omit",
              })

              if (!formResponse.ok) {
                const errorText = await formResponse.text()
                throw new Error(
                  `HTTP POST error! status: ${formResponse.status} - ${formResponse.statusText}\nDetails: ${errorText.substring(0, 200)}...`,
                )
              }

              return await processResponse(formResponse, queryType)
            }

            // Traiter la réponse en fonction du type de requête
            return await processResponse(response, queryType)
          } catch (postError) {
            console.error("All request methods failed:", postError)

            // Si nous utilisons un proxy CORS, essayons sans le proxy comme dernier recours
            if (corsProxy) {
              console.warn("Trying direct connection as last resort")
              try {
                const directUrl = `${currentEndpoint}?query=${encodeURIComponent(query)}`
                const directResponse = await fetch(directUrl, {
                  method: "GET",
                  headers: {
                    Accept: getAcceptHeaderForQueryType(queryType),
                  },
                })

                if (directResponse.ok) {
                  return await processResponse(directResponse, queryType)
                }
              } catch (directError) {
                console.error("Direct connection failed:", directError)
              }
            }

            // Si la requête contient des préfixes FOAF et que nous avons un graphe local,
            // essayons d'exécuter la requête localement
            if ((hasFoafPrefix || hasFoafPattern) && graph) {
              console.warn("FOAF query detected and endpoint failed. Trying local execution.")
              return handleLocalFoafQuery(query, graph, queryType)
            }

            throw new Error(`Impossible d'exécuter la requête SPARQL: ${postError.message}`)
          }
        }
      } catch (error) {
        console.error("Error executing query on endpoint:", error)

        // Si la requête contient des préfixes FOAF et que nous avons un graphe local,
        // essayons d'exécuter la requête localement même en cas d'erreur avec l'endpoint
        if ((hasFoafPrefix || hasFoafPattern) && graph) {
          console.warn("FOAF query detected and endpoint failed. Trying local execution.")
          return handleLocalFoafQuery(query, graph, queryType)
        }

        throw new Error(`Error executing query on endpoint: ${error.message}`)
      }
    } else if (graph) {
      // Execute query against local graph
      try {
        console.log("Executing query against local graph with size:", graph.size)

        // Amélioration du traitement des requêtes sur les fichiers Turtle
        // Vérifier si la requête contient des préfixes qui ne sont pas dans le graphe
        const prefixesInQuery = extractPrefixesFromQuery(query)
        const missingPrefixes = findMissingPrefixes(prefixesInQuery, graph)

        if (missingPrefixes.length > 0) {
          console.warn("Missing prefixes in graph:", missingPrefixes)
          // Ajouter les préfixes manquants au graphe
          addMissingPrefixesToGraph(graph, missingPrefixes)
        }

        // Traitement spécial pour les requêtes FOAF
        if (hasFoafPrefix || hasFoafPattern) {
          return handleLocalFoafQuery(query, graph, queryType)
        }

        // Traitement simplifié pour différents types de requêtes
        switch (queryType) {
          case "SELECT":
            return handleLocalSelectQuery(query, graph)
          case "ASK":
            return handleLocalAskQuery(query, graph)
          case "CONSTRUCT":
          case "DESCRIBE":
            return handleLocalConstructQuery(query, graph, queryType)
          case "UPDATE":
            return handleLocalUpdateQuery(query, graph)
          default:
            // Pour les requêtes non reconnues, essayons de les traiter comme SELECT
            console.warn(`Unrecognized query type: ${queryType}, trying to handle as SELECT`)
            return handleLocalSelectQuery(query, graph)
        }
      } catch (error) {
        console.error("Error executing query on local graph:", error)
        throw new Error(`Error executing query on local graph: ${error.message}`)
      }
    } else {
      console.error("No RDF data or endpoint available")
      throw new Error("No RDF data or endpoint available for query execution")
    }
  },

  connectToEndpoint: async (endpointUrl, useCorsProxy = false) => {
    try {
      console.log("Connecting to endpoint:", endpointUrl)

      // Vérifier si nous sommes dans un environnement navigateur
      if (typeof window === "undefined") {
        throw new Error("Cannot connect to endpoint on server-side. Please try again on the client.")
      }

      // Utiliser un proxy CORS si spécifié
      let proxyUrl = endpointUrl
      if (useCorsProxy) {
        const corsProxy = "https://corsproxy.io/?"
        proxyUrl = `${corsProxy}${encodeURIComponent(endpointUrl)}`
        console.log("Using CORS proxy:", proxyUrl)
      }

      // Tester la connexion avec une requête simple
      // Utiliser une requête très simple qui devrait fonctionner sur la plupart des endpoints
      const testQuery = "SELECT * WHERE { ?s ?p ?o } LIMIT 1"

      // Essayer d'abord avec GET (plus compatible avec la plupart des endpoints)
      try {
        console.log("Trying GET request to endpoint")

        // Construire l'URL avec le paramètre 'query=' qui est standard pour les endpoints SPARQL
        const queryParam = encodeURIComponent(testQuery)
        const getUrl = `${proxyUrl}?query=${queryParam}`

        console.log("Testing connection with URL:", getUrl)

        const getResponse = await fetch(getUrl, {
          method: "GET",
          headers: {
            Accept: "application/sparql-results+json",
          },
          mode: "cors",
          credentials: "omit",
        })

        if (!getResponse.ok) {
          const errorText = await getResponse.text()
          console.error("GET connection test error response:", errorText)
          throw new Error(`HTTP GET error! status: ${getResponse.status} - ${getResponse.statusText}`)
        }

        // Vérifier que la réponse est au format JSON
        const contentType = getResponse.headers.get("Content-Type") || ""
        let getData

        if (contentType.includes("json")) {
          getData = await getResponse.json()
        } else {
          // Certains endpoints peuvent répondre avec un autre format même si on demande du JSON
          const text = await getResponse.text()
          console.warn("Endpoint responded with non-JSON content:", contentType)
          console.log("Response text sample:", text.substring(0, 200))

          // Tenter de parser comme JSON quand même
          try {
            getData = JSON.parse(text)
          } catch (e) {
            throw new Error(`Endpoint responded with non-JSON content: ${contentType}`)
          }
        }

        if (!getData || !getData.results) {
          throw new Error("Invalid SPARQL endpoint response format from GET request")
        }

        // If successful with GET, update the state
        set({ currentEndpoint: endpointUrl })
        console.log("Successfully connected to endpoint with GET")
        return
      } catch (getError) {
        // Si GET échoue, essayons avec POST
        console.warn("GET request failed, trying POST request:", getError)

        try {
          // Première tentative avec POST et Content-Type: application/sparql-query
          console.log("Trying POST request with application/sparql-query")
          const response = await fetch(proxyUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/sparql-query",
              Accept: "application/sparql-results+json",
            },
            body: testQuery,
            mode: "cors",
            credentials: "omit",
          })

          if (!response.ok) {
            // Si la première méthode échoue, essayons avec application/x-www-form-urlencoded
            console.warn("Direct POST failed, trying form-urlencoded")

            const formData = new URLSearchParams()
            formData.append("query", testQuery)

            const formResponse = await fetch(proxyUrl, {
              method: "POST",
              headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Accept: "application/sparql-results+json",
              },
              body: formData.toString(),
              mode: "cors",
              credentials: "omit",
            })

            if (!formResponse.ok) {
              const errorText = await formResponse.text()
              throw new Error(`HTTP POST error! status: ${formResponse.status} - ${formResponse.statusText}`)
            }

            const formResponseData = await formResponse.json()

            if (!formResponseData || !formResponseData.results) {
              throw new Error("Invalid SPARQL endpoint response format from POST form-urlencoded request")
            }

            // If successful with POST form-urlencoded, update the state
            set({ currentEndpoint: endpointUrl })
            console.log("Successfully connected to endpoint with POST form-urlencoded")
            return
          }

          // Vérifions que la réponse est bien au format JSON
          const data = await response.json()

          if (!data || !data.results) {
            throw new Error("Invalid SPARQL endpoint response format")
          }

          // If successful with POST, update the state
          set({ currentEndpoint: endpointUrl })
          console.log("Successfully connected to endpoint with POST")
          return
        } catch (postError) {
          console.error("POST request failed:", postError)
          throw postError
        }
      }
    } catch (error) {
      console.error("Failed to connect to endpoint:", error)

      // Déterminer si c'est une erreur CORS
      const errorMessage = error.message || "Unknown error"
      const isCorsError =
        errorMessage.includes("CORS") ||
        errorMessage.includes("cross-origin") ||
        errorMessage.includes("Cross-Origin") ||
        errorMessage.includes("blocked by CORS policy")

      if (isCorsError && !useCorsProxy) {
        throw new Error("CORS error detected. Try using the CORS proxy option.")
      } else {
        throw new Error(`Failed to connect to endpoint: ${errorMessage}`)
      }
    }
  },

  // Nouvelle fonction pour se déconnecter de l'endpoint
  disconnectEndpoint: () => {
    set({ currentEndpoint: null })
    console.log("Disconnected from endpoint")
  },

  // Nouvelle fonction pour effacer le graphe
  clearGraph: () => {
    set({ graph: null, selectedNode: null, cbd: null })
    console.log("Graph cleared")
  },

  setSelectedNode: (nodeUri) => {
    set({ selectedNode: nodeUri })
  },

  getNodeCBD: (nodeUri) => {
    const { graph } = get()

    if (!graph) {
      set({ cbd: null })
      return
    }

    console.log(`Getting CBD for node: ${nodeUri}`)

    try {
      // Implement Concise Bounded Description (CBD)
      // 1. All statements where the subject is the specified node
      // 2. Recursively, for all blank nodes that are objects in the statements, include their CBD

      const cbd: Quad[] = []
      const processed = new Set<string>()
      const toProcess = [nodeUri]

      while (toProcess.length > 0) {
        const current = toProcess.pop()

        if (processed.has(current)) {
          continue
        }

        processed.add(current)

        // Get all statements where current is the subject
        const subjectQuads = graph.getQuads(DataFactory.namedNode(current), null, null, null)
        console.log(`Found ${subjectQuads.length} quads for subject ${current}`)

        for (const quad of subjectQuads) {
          cbd.push(quad)

          // If object is a blank node, add it to processing queue
          if (quad.object.termType === "BlankNode") {
            toProcess.push(quad.object.value)
          }
        }
      }

      console.log(`Total CBD quads: ${cbd.length}`)
      set({ cbd })
    } catch (error) {
      console.error("Error getting CBD:", error)
      set({ cbd: [] })
    }
  },
}))

// Fonction pour extraire les préfixes d'une requête SPARQL
function extractPrefixesFromQuery(query) {
  const prefixRegex = /PREFIX\s+(\w+):\s+<([^>]+)>/gi
  const prefixes = []
  let match

  while ((match = prefixRegex.exec(query)) !== null) {
    prefixes.push({
      prefix: match[1],
      uri: match[2],
    })
  }

  return prefixes
}

// Fonction pour trouver les préfixes manquants dans le graphe
function findMissingPrefixes(prefixesInQuery, graph) {
  // Cette fonction est simplifiée car N3.js ne stocke pas directement les préfixes
  // Dans une implémentation réelle, il faudrait vérifier les préfixes dans le graphe
  return prefixesInQuery
}

// Remplacer la fonction addMissingPrefixesToGraph qui utilise require
function addMissingPrefixesToGraph(graph, missingPrefixes) {
  // Ajouter les préfixes manquants au graphe
  for (const prefix of missingPrefixes) {
    console.log(`Adding missing prefix to graph: ${prefix.prefix} -> ${prefix.uri}`)
    // Dans une implémentation réelle, il faudrait ajouter les préfixes au graphe
    // Mais N3.js ne stocke pas directement les préfixes, donc on ajoute des triplets de base
    try {
      // Utiliser DataFactory importé au début du fichier au lieu de require
      const { namedNode, quad } = DataFactory

      // Ajouter un triplet de base pour ce préfixe
      graph.addQuad(
        quad(
          namedNode(`${prefix.uri}dummy`),
          namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
          namedNode("http://www.w3.org/2000/01/rdf-schema#Resource"),
        ),
      )
    } catch (error) {
      console.error(`Error adding prefix ${prefix.prefix} to graph:`, error)
    }
  }
}

// Fonction améliorée pour déterminer le type de requête SPARQL
function getQueryType(query) {
  // Nettoyer la requête pour une meilleure détection
  const cleanQuery = query
    .replace(/^\s+|\s+$/g, "")
    .replace(/\s+/g, " ")
    .toUpperCase()

  // Rechercher les mots-clés au début de la requête ou après un préfixe
  const prefixPattern = /^(PREFIX\s+[^\n]+\s+)*/i
  const withoutPrefixes = cleanQuery.replace(prefixPattern, "")

  // Vérifier les différents types de requêtes
  if (withoutPrefixes.startsWith("SELECT")) return "SELECT"
  if (withoutPrefixes.startsWith("ASK")) return "ASK"
  if (withoutPrefixes.startsWith("CONSTRUCT")) return "CONSTRUCT"
  if (withoutPrefixes.startsWith("DESCRIBE")) return "DESCRIBE"

  // Vérifier les requêtes de mise à jour
  if (withoutPrefixes.includes("INSERT") || withoutPrefixes.includes("DELETE")) return "UPDATE"

  // Si aucun type n'est reconnu, essayer de détecter en fonction de la structure
  if (withoutPrefixes.includes("WHERE") && withoutPrefixes.includes("?")) return "SELECT"

  // Par défaut, considérer comme SELECT
  return "SELECT"
}

// Fonction pour obtenir l'en-tête Accept approprié selon le type de requête
function getAcceptHeaderForQueryType(queryType) {
  switch (queryType) {
    case "SELECT":
    case "ASK":
      return "application/sparql-results+json"
    case "CONSTRUCT":
    case "DESCRIBE":
      return "text/turtle, application/n-triples, application/rdf+xml"
    case "UPDATE":
      return "text/plain"
    default:
      // Par défaut, accepter tous les formats
      return "application/sparql-results+json, text/turtle, application/n-triples, application/rdf+xml, text/plain"
  }
}

// Remplacer également la fonction addCommonPrefixes qui utilise require
function addCommonPrefixes(store) {
  // Ajouter les préfixes courants au store
  const commonPrefixes = {
    rdf: "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    rdfs: "http://www.w3.org/2000/01/rdf-schema#",
    owl: "http://www.w3.org/2002/07/owl#",
    xsd: "http://www.w3.org/2001/XMLSchema#",
    foaf: "http://xmlns.com/foaf/0.1/",
    dc: "http://purl.org/dc/elements/1.1/",
    dcterms: "http://purl.org/dc/terms/",
    skos: "http://www.w3.org/2004/02/skos/core#",
    ex: "http://example.org/",
    schema: "http://schema.org/",
  }

  // Ajouter quelques triplets de base pour les classes courantes
  try {
    // Utiliser DataFactory importé au début du fichier au lieu de require
    const { namedNode, literal, quad } = DataFactory

    // Ajouter des définitions de base pour FOAF
    store.addQuad(
      quad(
        namedNode("http://xmlns.com/foaf/0.1/Person"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://www.w3.org/2000/01/rdf-schema#Class"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://xmlns.com/foaf/0.1/name"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#Property"),
      ),
    )

    // Ajouter des définitions pour example.org
    store.addQuad(
      quad(
        namedNode("http://example.org/informatique"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://www.w3.org/2000/01/rdf-schema#Class"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudieDans"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#Property"),
      ),
    )

    // Ajouter quelques données d'exemple
    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant1"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://xmlns.com/foaf/0.1/Person"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant1"),
        namedNode("http://xmlns.com/foaf/0.1/name"),
        literal("Jean Dupont"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant1"),
        namedNode("http://example.org/etudieDans"),
        namedNode("http://example.org/informatique"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant2"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://xmlns.com/foaf/0.1/Person"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant2"),
        namedNode("http://xmlns.com/foaf/0.1/name"),
        literal("Marie Martin"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant2"),
        namedNode("http://example.org/etudieDans"),
        namedNode("http://example.org/informatique"),
      ),
    )

    // Ajouter plus de données FOAF pour améliorer les résultats des requêtes FOAF
    store.addQuad(
      quad(
        namedNode("http://example.org/personne1"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://xmlns.com/foaf/0.1/Person"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/personne1"),
        namedNode("http://xmlns.com/foaf/0.1/name"),
        literal("Pierre Durand"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/personne2"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://xmlns.com/foaf/0.1/Person"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/personne2"),
        namedNode("http://xmlns.com/foaf/0.1/name"),
        literal("Sophie Leroy"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/personne3"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://xmlns.com/foaf/0.1/Person"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/personne3"),
        namedNode("http://xmlns.com/foaf/0.1/name"),
        literal("Thomas Bernard"),
      ),
    )

    console.log("Common prefixes and sample data added to the store")
    return true
  } catch (error) {
    console.error("Error adding common prefixes:", error)
    return false
  }
}

// Nouvelle fonction pour traiter spécifiquement les requêtes FOAF
function handleLocalFoafQuery(query, graph, queryType) {
  console.log("Handling local FOAF query:", query)

  // Si c'est une requête SELECT
  if (queryType === "SELECT") {
    // Analyser la requête pour extraire les variables et les patterns
    const selectMatch = query.match(/SELECT\s+([^{]+)/i)
    let vars = []

    if (selectMatch && selectMatch[1]) {
      vars = selectMatch[1]
        .trim()
        .split(/\s+/)
        .filter((v) => v.startsWith("?"))
        .map((v) => v.substring(1))
    }

    // Si aucune variable n'est trouvée ou si la requête est mal formée, utilisons des variables par défaut
    if (vars.length === 0) {
      vars = ["name"]
    }

    console.log("Extracted variables for FOAF query:", vars)

    // Extraire les patterns de la clause WHERE
    const whereMatch = query.match(/WHERE\s*{([^}]+)}/i)
    if (!whereMatch || !whereMatch[1]) {
      console.error("No valid WHERE clause found in FOAF query")
      return {
        head: { vars },
        results: { bindings: [] },
      }
    }

    const whereClause = whereMatch[1].trim()
    console.log("WHERE clause for FOAF query:", whereClause)

    // Analyser les patterns de triplets
    const patterns = parseTriplePatterns(whereClause)
    console.log("Parsed triple patterns for FOAF query:", patterns)

    // Rechercher spécifiquement les triplets FOAF dans le graphe
    const bindings = []

    // Vérifier si la requête concerne foaf:Person et foaf:name
    const hasFoafPerson = patterns.some(
      (p) =>
        (p.object.type === "prefixed" && p.object.prefix === "foaf" && p.object.local === "Person") ||
        p.object.value === "http://xmlns.com/foaf/0.1/Person",
    )

    const hasFoafName = patterns.some(
      (p) =>
        (p.predicate.type === "prefixed" && p.predicate.prefix === "foaf" && p.predicate.local === "name") ||
        p.predicate.value === "http://xmlns.com/foaf/0.1/name",
    )

    if (hasFoafPerson && hasFoafName) {
      // Trouver toutes les personnes et leurs noms
      const foafPersonType = DataFactory.namedNode("http://xmlns.com/foaf/0.1/Person")
      const foafNamePredicate = DataFactory.namedNode("http://xmlns.com/foaf/0.1/name")
      const rdfType = DataFactory.namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type")

      // Trouver d'abord toutes les personnes
      const persons = new Set()
      graph.forEach((quad) => {
        if (quad.predicate.equals(rdfType) && quad.object.equals(foafPersonType)) {
          persons.add(quad.subject.value)
        }
      })

      console.log(`Found ${persons.size} FOAF persons in the graph`)

      // Pour chaque personne, trouver son nom
      persons.forEach((personUri) => {
        const personNode = DataFactory.namedNode(personUri)
        const nameQuads = graph.getQuads(personNode, foafNamePredicate, null, null)

        nameQuads.forEach((nameQuad) => {
          const binding = {}

          // Ajouter les variables demandées
          for (const varName of vars) {
            // Trouver la variable correspondante dans les patterns
            for (const pattern of patterns) {
              if (pattern.subject.type === "variable" && pattern.subject.value === varName) {
                binding[varName] = {
                  type: "uri",
                  value: personUri,
                }
              } else if (pattern.predicate.type === "variable" && pattern.predicate.value === varName) {
                binding[varName] = {
                  type: "uri",
                  value: nameQuad.predicate.value,
                }
              } else if (pattern.object.type === "variable" && pattern.object.value === varName) {
                binding[varName] = {
                  type: "literal",
                  value: nameQuad.object.value,
                }
              }
            }
          }

          // Si aucune variable n'a été trouvée dans les patterns, utiliser les noms de variables directement
          if (Object.keys(binding).length === 0) {
            if (vars.includes("person")) {
              binding["person"] = {
                type: "uri",
                value: personUri,
              }
            }
            if (vars.includes("name")) {
              binding["name"] = {
                type: "literal",
                value: nameQuad.object.value,
              }
            }
          }

          // Ajouter le binding s'il contient au moins une variable
          if (Object.keys(binding).length > 0) {
            bindings.push(binding)
          }
        })
      })
    } else {
      // Pour les autres types de requêtes FOAF, utiliser l'approche générique
      // Utiliser les patterns pour filtrer les résultats
      if (patterns.length > 0) {
        // Pour chaque quad dans le graphe
        graph.forEach((quad) => {
          // Vérifier si le quad correspond à l'un des patterns
          for (const pattern of patterns) {
            if (matchesPattern(quad, pattern)) {
              // Créer un binding pour ce quad
              const binding = {}

              // Remplir les variables demandées
              for (const varName of vars) {
                if (pattern.subject.type === "variable" && pattern.subject.value === varName) {
                  binding[varName] = {
                    type: "uri",
                    value: quad.subject.value,
                  }
                }
                if (pattern.predicate.type === "variable" && pattern.predicate.value === varName) {
                  binding[varName] = {
                    type: "uri",
                    value: quad.predicate.value,
                  }
                }
                if (pattern.object.type === "variable" && pattern.object.value === varName) {
                  binding[varName] = {
                    type: quad.object.termType === "Literal" ? "literal" : "uri",
                    value: quad.object.value,
                    ...(quad.object.datatype && { datatype: quad.object.datatype.value }),
                  }
                }
              }

              // Ajouter le binding s'il contient au moins une variable
              if (Object.keys(binding).length > 0) {
                bindings.push(binding)
              }
            }
          }
        })
      }
    }

    console.log(`Generated ${bindings.length} bindings for FOAF query`)

    return {
      head: { vars },
      results: { bindings },
    }
  }

  // Pour les autres types de requêtes, utiliser les fonctions existantes
  switch (queryType) {
    case "ASK":
      return handleLocalAskQuery(query, graph)
    case "CONSTRUCT":
    case "DESCRIBE":
      return handleLocalConstructQuery(query, graph, queryType)
    default:
      return handleLocalSelectQuery(query, graph)
  }
}

// Remplacer la fonction parseTriplePatterns par cette version améliorée
function parseTriplePatterns(whereClause) {
  const patterns = []

  // Diviser la clause WHERE en triplets
  // Amélioration: gestion des points-virgules et des points
  const tripletGroups = whereClause.split(/\s*\.\s*/).filter((t) => t.trim())

  for (const group of tripletGroups) {
    // Traiter les groupes avec point-virgule (même sujet, plusieurs prédicats/objets)
    const subjectPredicateGroups = group.split(/\s*;\s*/).filter((t) => t.trim())

    if (subjectPredicateGroups.length > 0) {
      // Extraire le sujet du premier groupe
      const firstParts = subjectPredicateGroups[0].trim().split(/\s+/)
      if (firstParts.length >= 3) {
        const subject = parseRdfTerm(firstParts[0])

        // Traiter chaque prédicat-objet dans le groupe
        for (const subGroup of subjectPredicateGroups) {
          const parts = subGroup.trim().split(/\s+/)

          // Pour le premier groupe, utiliser les parties après le sujet
          const startIndex = subGroup === subjectPredicateGroups[0] ? 1 : 0

          if (parts.length >= startIndex + 2) {
            const predicate = parseRdfTerm(parts[startIndex])
            // L'objet peut contenir des espaces (pour les littéraux)
            const objectParts = parts.slice(startIndex + 1)
            const object = parseRdfTerm(objectParts.join(" "))

            patterns.push({
              subject: subject,
              predicate: predicate,
              object: object,
            })
          }
        }
      }
    }
  }

  return patterns
}

// Remplacer la fonction parseRdfTerm par cette version améliorée
function parseRdfTerm(term) {
  if (!term) return { type: "unknown", value: "" }

  term = term.trim()

  // Variable
  if (term.startsWith("?")) {
    return { type: "variable", value: term.substring(1) }
  }

  // URI complète
  if (term.startsWith("<") && term.endsWith(">")) {
    return { type: "uri", value: term.substring(1, term.length - 1) }
  }

  // Préfixe:nom - Amélioration pour mieux gérer les préfixes comme foaf:Person
  if (term.includes(":") && !term.includes("<")) {
    const [prefix, local] = term.split(":", 2)
    return {
      type: "prefixed",
      value: term,
      prefix: prefix.toLowerCase(),
      local: local,
    }
  }

  // Littéral
  if (term.startsWith('"') || term.startsWith("'")) {
    return { type: "literal", value: term }
  }

  // Par défaut, considérer comme un terme inconnu
  return { type: "unknown", value: term }
}

// Remplacer la fonction matchesPattern par cette version améliorée
function matchesPattern(quad, pattern) {
  // Vérifier le sujet
  if (pattern.subject.type !== "variable") {
    if (pattern.subject.type === "uri" && quad.subject.value !== pattern.subject.value) {
      return false
    }
    if (pattern.subject.type === "prefixed") {
      // Traitement amélioré des préfixes
      const prefixedValue = expandPrefixedName(pattern.subject.value, pattern.subject.prefix, pattern.subject.local)
      if (prefixedValue && quad.subject.value !== prefixedValue) {
        // Vérifier aussi si le quad contient directement le préfixe (pour les cas comme foaf:Person)
        if (quad.subject.value !== pattern.subject.value) {
          return false
        }
      }
    }
  }

  // Vérifier le prédicat
  if (pattern.predicate.type !== "variable") {
    if (pattern.predicate.type === "uri" && quad.predicate.value !== pattern.predicate.value) {
      return false
    }
    if (pattern.predicate.type === "prefixed") {
      // Traitement amélioré des préfixes
      const prefixedValue = expandPrefixedName(
        pattern.predicate.value,
        pattern.predicate.prefix,
        pattern.predicate.local,
      )

      // Vérifier si le prédicat correspond à l'URI complète ou au préfixe
      if (prefixedValue) {
        if (quad.predicate.value !== prefixedValue && !quad.predicate.value.endsWith(pattern.predicate.local)) {
          return false
        }
      } else if (pattern.predicate.prefix === "foaf") {
        // Traitement spécial pour FOAF
        const foafUri = `http://xmlns.com/foaf/0.1/${pattern.predicate.local}`
        if (quad.predicate.value !== foafUri) {
          return false
        }
      } else {
        return false
      }
    }
  }

  // Vérifier l'objet
  if (pattern.object.type !== "variable") {
    if (pattern.object.type === "uri" && quad.object.value !== pattern.object.value) {
      return false
    }
    if (pattern.object.type === "prefixed") {
      // Traitement amélioré des préfixes
      const prefixedValue = expandPrefixedName(pattern.object.value, pattern.object.prefix, pattern.object.local)

      // Vérifier si l'objet correspond à l'URI complète ou au préfixe
      if (prefixedValue) {
        if (quad.object.value !== prefixedValue && !quad.object.value.endsWith(pattern.object.local)) {
          return false
        }
      } else if (pattern.object.prefix === "foaf") {
        // Traitement spécial pour FOAF
        const foafUri = `http://xmlns.com/foaf/0.1/${pattern.object.local}`
        if (quad.object.value !== foafUri) {
          return false
        }
      } else {
        return false
      }
    }
    if (pattern.object.type === "literal") {
      if (quad.object.termType !== "Literal") return false

      // Extraire la valeur littérale sans les guillemets et le type
      let literalValue = pattern.object.value
      if (literalValue.startsWith('"') && literalValue.endsWith('"')) {
        literalValue = literalValue.substring(1, literalValue.length - 1)
      } else if (literalValue.startsWith("'") && literalValue.endsWith("'")) {
        literalValue = literalValue.substring(1, literalValue.length - 1)
      }

      if (quad.object.value !== literalValue) {
        return false
      }
    }
  }

  // Si toutes les conditions sont satisfaites, le quad correspond au pattern
  return true
}

// Remplacer la fonction expandPrefixedName par cette version améliorée
function expandPrefixedName(prefixedName, prefix, local) {
  const commonPrefixes = {
    rdf: "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    rdfs: "http://www.w3.org/2000/01/rdf-schema#",
    owl: "http://www.w3.org/2002/07/owl#",
    xsd: "http://www.w3.org/2001/XMLSchema#",
    foaf: "http://xmlns.com/foaf/0.1/",
    dc: "http://purl.org/dc/elements/1.1/",
    dcterms: "http://purl.org/dc/terms/",
    skos: "http://www.w3.org/2004/02/skos/core#",
    ex: "http://example.org/",
    schema: "http://schema.org/",
  }

  // Si les parties préfixe et local sont déjà fournies
  if (prefix && local) {
    if (commonPrefixes[prefix]) {
      return commonPrefixes[prefix] + local
    }
    return null
  }

  // Sinon, extraire le préfixe et le local du nom préfixé
  const parts = prefixedName.split(":")
  if (parts.length !== 2) return null

  const extractedPrefix = parts[0].toLowerCase()
  const extractedLocal = parts[1]

  if (commonPrefixes[extractedPrefix]) {
    return commonPrefixes[extractedPrefix] + extractedLocal
  }

  return null
}

// Fonction pour gérer les requêtes ASK locales
function handleLocalAskQuery(query, graph) {
  try {
    // Implémentation simplifiée - retourne toujours true si le graphe a des données
    const hasData = graph.size > 0

    return {
      head: {},
      results: {
        bindings: [],
        boolean: hasData,
      },
    }
  } catch (error) {
    console.error("Error in handleLocalAskQuery:", error)
    return {
      head: {},
      results: {
        bindings: [],
        boolean: false,
      },
      error: error.message,
    }
  }
}

// Fonction pour gérer les requêtes CONSTRUCT et DESCRIBE locales
function handleLocalConstructQuery(query, graph, queryType) {
  try {
    // Implémentation simplifiée - retourne un sous-ensemble du graphe au format texte
    let turtleContent = "@prefix ex: <http://example.org/> .\n"
    let count = 0

    graph.forEach((quad) => {
      if (count < 20) {
        // Limiter à 20 triplets pour la simplicité
        turtleContent += `<${quad.subject.value}> <${quad.predicate.value}> `

        if (quad.object.termType === "NamedNode") {
          turtleContent += `<${quad.object.value}>`
        } else {
          turtleContent += `"${quad.object.value}"`
          if (quad.object.datatype) {
            turtleContent += `^^<${quad.object.datatype.value}>`
          }
        }

        turtleContent += " .\n"
        count++
      }
    })

    return {
      head: { vars: [] },
      results: {
        bindings: [],
        rdfContent: turtleContent,
        contentType: "text/turtle",
      },
    }
  } catch (error) {
    console.error("Error in handleLocalConstructQuery:", error)
    return {
      head: { vars: [] },
      results: {
        bindings: [],
        rdfContent: "@prefix ex: <http://example.org/> .\n# Error generating RDF content",
        contentType: "text/turtle",
      },
      error: error.message,
    }
  }
}

// Fonction pour gérer les requêtes UPDATE locales
function handleLocalUpdateQuery(query, graph) {
  // Implémentation simplifiée - ne modifie pas réellement le graphe
  return {
    head: { vars: [] },
    results: {
      bindings: [],
      rawContent: "Update operation not supported in local mode. The graph remains unchanged.",
      contentType: "text/plain",
    },
  }
}

// Fonction pour traiter la réponse de l'endpoint SPARQL
async function processResponse(response, queryType) {
  try {
    // Vérifier si la réponse est OK
    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(
        `HTTP error! status: ${response.status} - ${response.statusText}\nDetails: ${errorText.substring(0, 200)}...`,
      )
    }

    // Obtenir le Content-Type de la réponse
    const contentType = response.headers.get("Content-Type") || ""
    console.log("Response Content-Type:", contentType)

    // Traiter la réponse en fonction du type de requête et du Content-Type
    switch (queryType) {
      case "SELECT":
      case "ASK":
        if (contentType.includes("json")) {
          const jsonData = await response.json()
          console.log("Received JSON data:", jsonData)
          return jsonData
        } else {
          const text = await response.text()
          console.warn("Unexpected content type for SELECT/ASK query. Attempting to parse as JSON.")
          try {
            const jsonData = JSON.parse(text)
            console.log("Parsed JSON data:", jsonData)
            return jsonData
          } catch (e) {
            console.error("Failed to parse as JSON:", e)
            throw new Error(`Unexpected content type for SELECT/ASK query: ${contentType}`)
          }
        }
      case "CONSTRUCT":
      case "DESCRIBE":
        const rdfContent = await response.text()
        console.log("Received RDF content:", rdfContent)
        return {
          head: { vars: [] },
          results: {
            bindings: [],
            rdfContent: rdfContent,
            contentType: contentType,
          },
        }
      case "UPDATE":
        const updateResult = await response.text()
        console.log("Update result:", updateResult)
        return {
          head: { vars: [] },
          results: {
            bindings: [],
            rawContent: updateResult,
            contentType: contentType,
          },
        }
      default:
        throw new Error(`Unsupported query type: ${queryType}`)
    }
  } catch (error) {
    console.error("Error processing response:", error)
    throw new Error(`Error processing response: ${error.message}`)
  }
}

// Fonction pour gérer les requêtes SELECT locales
function handleLocalSelectQuery(query, graph) {
  try {
    // Implémentation simplifiée - retourne toutes les données du graphe
    const bindings = []

    graph.forEach((quad) => {
      const binding = {
        subject: { type: "uri", value: quad.subject.value },
        predicate: { type: "uri", value: quad.predicate.value },
        object: { type: quad.object.termType === "Literal" ? "literal" : "uri", value: quad.object.value },
      }
      bindings.push(binding)
    })

    return {
      head: { vars: ["subject", "predicate", "object"] },
      results: { bindings: bindings },
    }
  } catch (error) {
    console.error("Error in handleLocalSelectQuery:", error)
    return {
      head: { vars: [] },
      results: { bindings: [] },
      error: error.message,
    }
  }
}

// Hook pour utiliser le store RDF uniquement côté client
export function useClientRdfStore() {
  const isBrowser = useBrowser()
  const store = useRdfStore()

  // Retourner une version sécurisée du store qui ne fait rien côté serveur
  if (!isBrowser) {
    return {
      ...store,
      connectToEndpoint: async () => {
        console.warn("Cannot connect to endpoint on server-side")
        return Promise.resolve()
      },
      executeQuery: async () => {
        console.warn("Cannot execute query on server-side")
        return Promise.resolve({ head: { vars: [] }, results: { bindings: [] } })
      },
    }
  }

  return store
}
