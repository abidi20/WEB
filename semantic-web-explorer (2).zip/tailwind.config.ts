import type { Config } from "tailwindcss"

const config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        semantic: {
          blue: "#3a86ff",
          purple: "#8338ec",
          pink: "#ff006e",
          teal: "#00b4d8",
          green: "#06d6a0",
          orange: "#fb5607",
          yellow: "#ffbe0b",
          gradient: {
            start: "#8338ec",
            end: "#3a86ff",
          },
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "fade-in": {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(10px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pulse-slow": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.8" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
        glow: {
          "0%, 100%": { boxShadow: "0 0 5px rgba(131, 56, 236, 0.5)" },
          "50%": { boxShadow: "0 0 20px rgba(131, 56, 236, 0.8)" },
        },
        "rotate-slow": {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(360deg)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-1000px 0" },
          "100%": { backgroundPosition: "1000px 0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fade-in": "fade-in 0.5s ease-out",
        "fade-up": "fade-up 0.5s ease-out",
        "pulse-slow": "pulse-slow 3s infinite",
        float: "float 6s ease-in-out infinite",
        glow: "glow 2s ease-in-out infinite",
        "rotate-slow": "rotate-slow 10s linear infinite",
        shimmer: "shimmer 2s linear infinite",
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "semantic-gradient": "linear-gradient(to right, #8338ec, #3a86ff)",
        "semantic-gradient-alt": "linear-gradient(to right, #ff006e, #00b4d8)",
        "semantic-gradient-warm": "linear-gradient(to right, #fb5607, #ffbe0b)",
        "semantic-gradient-cool": "linear-gradient(to right, #00b4d8, #06d6a0)",
        "semantic-mesh":
          "radial-gradient(at 40% 20%, rgba(131, 56, 236, 0.1) 0px, transparent 50%), radial-gradient(at 80% 0%, rgba(58, 134, 255, 0.1) 0px, transparent 50%), radial-gradient(at 0% 50%, rgba(255, 0, 110, 0.1) 0px, transparent 50%), radial-gradient(at 80% 50%, rgba(0, 180, 216, 0.1) 0px, transparent 50%), radial-gradient(at 0% 100%, rgba(251, 86, 7, 0.1) 0px, transparent 50%), radial-gradient(at 80% 100%, rgba(6, 214, 160, 0.1) 0px, transparent 50%), radial-gradient(at 0% 0%, rgba(255, 190, 11, 0.1) 0px, transparent 50%)",
      },
      boxShadow: {
        "glow-sm": "0 0 5px rgba(131, 56, 236, 0.5)",
        "glow-md": "0 0 15px rgba(131, 56, 236, 0.5)",
        "glow-lg": "0 0 25px rgba(131, 56, 236, 0.5)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config

export default config
