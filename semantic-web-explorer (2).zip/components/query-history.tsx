"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Copy, Check, Trash2, History } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface QueryHistoryProps {
  queries: string[]
  onSelectQuery: (query: string) => void
  onClearHistory: () => void
}

export function QueryHistory({ queries, onSelectQuery, onClearHistory }: QueryHistoryProps) {
  const { toast } = useToast()
  const [copied, setCopied] = useState<number | null>(null)

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text).then(
      () => {
        setCopied(index)
        setTimeout(() => setCopied(null), 2000)
        toast({
          title: "Requête copiée",
          description: "La requête a été copiée dans le presse-papiers.",
        })
      },
      (err) => {
        toast({
          title: "Erreur",
          description: "Impossible de copier la requête: " + err,
          variant: "destructive",
        })
      },
    )
  }

  // Fonction pour déterminer le type de requête
  const getQueryType = (query: string) => {
    const cleanQuery = query
      .replace(/^\s+|\s+$/g, "")
      .replace(/\s+/g, " ")
      .toUpperCase()
    const prefixPattern = /^(PREFIX\s+[^\n]+\s+)*/i
    const withoutPrefixes = cleanQuery.replace(prefixPattern, "")

    if (withoutPrefixes.startsWith("SELECT")) return "SELECT"
    if (withoutPrefixes.startsWith("ASK")) return "ASK"
    if (withoutPrefixes.startsWith("CONSTRUCT")) return "CONSTRUCT"
    if (withoutPrefixes.startsWith("DESCRIBE")) return "DESCRIBE"
    if (withoutPrefixes.includes("INSERT") || withoutPrefixes.includes("DELETE")) return "UPDATE"

    return "UNKNOWN"
  }

  // Fonction pour obtenir la première ligne significative de la requête
  const getQuerySummary = (query: string) => {
    const lines = query.split("\n").filter((line) => line.trim() && !line.trim().startsWith("PREFIX"))
    if (lines.length === 0) return "Requête vide"

    const firstLine = lines[0].trim()
    return firstLine.length > 60 ? firstLine.substring(0, 57) + "..." : firstLine
  }

  // Fonction pour obtenir la date de la requête (simulée ici)
  const getQueryDate = (index: number) => {
    const date = new Date()
    date.setMinutes(date.getMinutes() - index * 10) // Simuler des requêtes espacées de 10 minutes
    return date.toLocaleString()
  }

  // Fonction pour obtenir la couleur du badge selon le type de requête
  const getBadgeColor = (type: string) => {
    switch (type) {
      case "SELECT":
        return "bg-semantic-blue"
      case "ASK":
        return "bg-semantic-green"
      case "CONSTRUCT":
        return "bg-semantic-purple"
      case "DESCRIBE":
        return "bg-semantic-teal"
      case "UPDATE":
        return "bg-semantic-pink"
      default:
        return "bg-slate-500"
    }
  }

  return (
    <Card className="border border-slate-200 dark:border-slate-700 shadow-lg bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-bold bg-semantic-gradient bg-clip-text text-transparent flex items-center">
          <History className="h-5 w-5 mr-2 text-semantic-purple" />
          Historique des Requêtes SPARQL
        </CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-300">
          Vos requêtes récentes sont sauvegardées automatiquement
        </CardDescription>
      </CardHeader>
      <CardContent>
        {queries.length === 0 ? (
          <Alert className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30">
            <AlertDescription className="text-sm">
              Aucune requête dans l'historique. Exécutez des requêtes pour les voir apparaître ici.
            </AlertDescription>
          </Alert>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="space-y-3">
              {queries.map((query, index) => {
                const queryType = getQueryType(query)
                const querySummary = getQuerySummary(query)
                const queryDate = getQueryDate(index)

                return (
                  <div
                    key={index}
                    className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <Badge className={`${getBadgeColor(queryType)} text-white`}>{queryType}</Badge>
                          <span className="text-xs text-slate-500">{queryDate}</span>
                        </div>
                        <h5 className="font-medium text-semantic-blue mt-1">{querySummary}</h5>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => copyToClipboard(query, index)}
                        >
                          {copied === index ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                        </Button>
                        <Button variant="outline" size="sm" className="h-7" onClick={() => onSelectQuery(query)}>
                          Utiliser
                        </Button>
                      </div>
                    </div>
                    <pre className="text-xs p-2 bg-slate-50 dark:bg-slate-900 rounded overflow-x-auto max-h-[100px]">
                      {query.split("\n").slice(0, 5).join("\n")}
                      {query.split("\n").length > 5 ? "\n..." : ""}
                    </pre>
                  </div>
                )
              })}
            </div>
          </ScrollArea>
        )}
      </CardContent>
      {queries.length > 0 && (
        <CardFooter>
          <Button onClick={onClearHistory} className="w-full bg-red-500 hover:bg-red-600 text-white transition-colors">
            <Trash2 className="h-4 w-4 mr-2" />
            Effacer l'historique
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}
