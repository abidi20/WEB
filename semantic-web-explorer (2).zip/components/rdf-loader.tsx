"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useRdfStore } from "@/lib/rdf-store"
import { Upload, FileType, Check, FileJson, FileText, FileCode, Trash2 } from "lucide-react"
import { useBrowser } from "@/hooks/use-browser"
import { Badge } from "@/components/ui/badge"

export function RdfLoader() {
  const { toast } = useToast()
  const { loadRdfFromFile, graph, clearGraph } = useRdfStore()
  const [file, setFile] = useState(null)
  const [format, setFormat] = useState("turtle")
  const [isLoading, setIsLoading] = useState(false)
  const isBrowser = useBrowser()

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
    }
  }

  const handleLoadRdf = async () => {
    if (!isBrowser) {
      toast({
        title: "Erreur",
        description: "Cette fonctionnalité n'est disponible que dans le navigateur.",
        variant: "destructive",
      })
      return
    }

    if (!file) {
      toast({
        title: "Aucun fichier sélectionné",
        description: "Veuillez sélectionner un fichier RDF à charger.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      console.log(`Loading RDF file: ${file.name} with format: ${format}`)
      await loadRdfFromFile(file, format)
      toast({
        title: "RDF Chargé",
        description: `Données RDF chargées avec succès depuis ${file.name}`,
      })
    } catch (error) {
      console.error("Error loading RDF:", error)
      toast({
        title: "Erreur de chargement RDF",
        description: error.message || "Une erreur s'est produite lors du chargement du fichier RDF.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Fonction pour effacer les données RDF
  const handleClearRdf = () => {
    clearGraph()
    setFile(null)
    toast({
      title: "Données effacées",
      description: "Les données RDF ont été effacées.",
    })
  }

  // Fonction pour déterminer le format automatiquement à partir de l'extension du fichier
  const detectFormatFromFileName = (fileName) => {
    const extension = fileName.split(".").pop().toLowerCase()
    switch (extension) {
      case "ttl":
        return "turtle"
      case "rdf":
      case "xml":
        return "rdfxml"
      case "nt":
        return "ntriples"
      case "n3":
        return "n3"
      case "jsonld":
        return "jsonld"
      default:
        return "turtle" // Format par défaut
    }
  }

  // Mettre à jour le format automatiquement lorsqu'un fichier est sélectionné
  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]
      setFile(selectedFile)
      setFormat(detectFormatFromFileName(selectedFile.name))
    }
  }

  // Fonction pour obtenir l'icône en fonction du format
  const getFormatIcon = (format) => {
    switch (format) {
      case "turtle":
        return <FileText className="h-5 w-5 text-semantic-blue" />
      case "rdfxml":
        return <FileCode className="h-5 w-5 text-semantic-purple" />
      case "jsonld":
        return <FileJson className="h-5 w-5 text-semantic-orange" />
      default:
        return <FileType className="h-5 w-5 text-semantic-teal" />
    }
  }

  return (
    <Card className="glass card-hover border-white/20 dark:border-slate-700/50 shadow-lg h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl font-bold bg-semantic-gradient bg-clip-text text-transparent flex items-center">
          <div className="h-10 w-10 rounded-full bg-semantic-blue/10 flex items-center justify-center mr-3 glow">
            <FileType className="h-6 w-6 text-semantic-blue" />
          </div>
          Charger des Données RDF
        </CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-300">
          Chargez des données RDF depuis un fichier local dans différents formats
          {graph && graph.size > 0 && (
            <div className="mt-2 flex items-center">
              <Badge className="bg-semantic-green text-white shadow-glow-sm">
                <Check className="h-3 w-3 mr-1" />
                Données chargées
              </Badge>
              <span className="ml-2 text-sm font-medium">{graph.size} triplets</span>

              {/* Bouton pour effacer les données */}
              <Button
                variant="outline"
                size="sm"
                onClick={handleClearRdf}
                className="ml-auto bg-red-50 hover:bg-red-100 text-red-600 border-red-200"
              >
                <Trash2 className="h-3 w-3 mr-1" />
                Effacer
              </Button>
            </div>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid w-full items-center gap-2">
          <label
            htmlFor="rdf-format"
            className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2"
          >
            {getFormatIcon(format)}
            Format RDF
          </label>
          <Select value={format} onValueChange={setFormat}>
            <SelectTrigger
              id="rdf-format"
              className="bg-white/70 dark:bg-slate-800/70 border-slate-200/50 dark:border-slate-700/50 backdrop-blur-sm"
            >
              <SelectValue placeholder="Sélectionner un format" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="turtle">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-semantic-blue" />
                  <span>Turtle (.ttl)</span>
                </div>
              </SelectItem>
              <SelectItem value="rdfxml">
                <div className="flex items-center gap-2">
                  <FileCode className="h-4 w-4 text-semantic-purple" />
                  <span>RDF/XML (.rdf, .xml)</span>
                </div>
              </SelectItem>
              <SelectItem value="ntriples">
                <div className="flex items-center gap-2">
                  <FileType className="h-4 w-4 text-semantic-teal" />
                  <span>N-Triples (.nt)</span>
                </div>
              </SelectItem>
              <SelectItem value="n3">
                <div className="flex items-center gap-2">
                  <FileType className="h-4 w-4 text-semantic-green" />
                  <span>Notation3 (.n3)</span>
                </div>
              </SelectItem>
              <SelectItem value="jsonld">
                <div className="flex items-center gap-2">
                  <FileJson className="h-4 w-4 text-semantic-orange" />
                  <span>JSON-LD (.jsonld)</span>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid w-full items-center gap-2">
          <label htmlFor="rdf-file" className="text-sm font-medium text-slate-700 dark:text-slate-300">
            Fichier RDF
          </label>
          <div className="flex flex-col gap-2">
            {file ? (
              <div className="p-4 rounded-lg border border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-semantic-blue/10 flex items-center justify-center mr-3 animate-pulse-slow">
                    <Check className="h-5 w-5 text-semantic-blue" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">{file.name}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{(file.size / 1024).toFixed(2)} KB</p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setFile(null)}
                  className="text-xs h-8 bg-white/70 dark:bg-slate-800/70 border-slate-200/50 dark:border-slate-700/50 backdrop-blur-sm"
                >
                  Changer
                </Button>
              </div>
            ) : (
              <Button
                variant="outline"
                onClick={() => document.getElementById("rdf-file").click()}
                className="h-24 border-dashed border-2 flex flex-col gap-2 hover:border-semantic-blue hover:text-semantic-blue transition-colors bg-white/30 dark:bg-slate-800/30 backdrop-blur-sm"
              >
                <Upload className="h-6 w-6" />
                <span>Choisir un fichier</span>
              </Button>
            )}
            <input
              id="rdf-file"
              type="file"
              className="hidden"
              onChange={handleFileSelect}
              accept=".ttl,.rdf,.xml,.nt,.n3,.jsonld"
            />
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2">
        <Button
          onClick={handleLoadRdf}
          disabled={!file || isLoading || !isBrowser}
          className="flex-1 bg-semantic-gradient hover:opacity-90 transition-opacity shadow-glow-sm"
        >
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
              <span>Chargement...</span>
            </div>
          ) : (
            "Charger les Données RDF"
          )}
        </Button>

        {graph && graph.size > 0 && (
          <Button onClick={handleClearRdf} className="bg-red-500 hover:bg-red-600 text-white transition-colors">
            <Trash2 className="h-4 w-4 mr-2" />
            Effacer
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
