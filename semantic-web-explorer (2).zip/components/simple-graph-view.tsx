"use client"

import { useState, useEffect, useRef } from "react"
import dynamic from "next/dynamic"
import { useBrowser } from "@/hooks/use-browser"

// Dynamically import ForceGraph2D with no SSR
const ForceGraph2D = dynamic(() => import("react-force-graph-2d"), { ssr: false })

export function SimpleGraphView({ results, onGraphDataUpdate }) {
  const [graphData, setGraphData] = useState({ nodes: [], links: [] })
  const isBrowser = useBrowser()
  const graphRef = useRef()
  const prevResultsRef = useRef(null)

  // Modifier la fonction useEffect pour éviter les mises à jour en boucle
  useEffect(() => {
    if (!isBrowser || !results) return

    // Vérifier si les résultats ont changé pour éviter les traitements inutiles
    if (prevResultsRef.current === results) return
    prevResultsRef.current = results

    try {
      console.log("Processing results for simple graph view:", results)

      // Créer un graphe simple à partir des résultats
      const nodes = []
      const links = []
      const nodeMap = new Map()

      // Obtenir les variables et les liaisons
      const vars = results.head?.vars || []
      const bindings = results.results?.bindings || []

      if (bindings.length === 0) {
        console.log("No bindings found in results")
        const newGraphData = { nodes: [], links: [] }
        setGraphData(newGraphData)

        // Notifier le parent des données du graphe mises à jour
        if (onGraphDataUpdate) {
          onGraphDataUpdate(newGraphData)
        }
        return
      }

      // Vérifier si nous avons un modèle sujet-prédicat-objet
      const hasSPO = vars.includes("subject") && vars.includes("predicate") && vars.includes("object")

      if (hasSPO) {
        // Traiter le modèle sujet-prédicat-objet
        bindings.forEach((row, index) => {
          if (row.subject && row.predicate && row.object) {
            const subjectId = row.subject.value
            const objectId = row.object.value
            const predicate = row.predicate.value

            // Ajouter le nœud sujet s'il n'existe pas déjà
            if (!nodeMap.has(subjectId)) {
              const node = {
                id: subjectId,
                name: subjectId.split("/").pop() || subjectId.split("#").pop() || subjectId,
                color: "#7209b7",
                size: 10,
              }
              nodeMap.set(subjectId, node)
              nodes.push(node)
            }

            // Ajouter le nœud objet s'il n'existe pas déjà et si c'est une URI
            if (!nodeMap.has(objectId) && row.object.type === "uri") {
              const node = {
                id: objectId,
                name: objectId.split("/").pop() || objectId.split("#").pop() || objectId,
                color: "#4361ee",
                size: 10,
              }
              nodeMap.set(objectId, node)
              nodes.push(node)
            }

            // Ajouter le lien si l'objet est une URI
            if (row.object.type === "uri") {
              links.push({
                source: subjectId,
                target: objectId,
                name: predicate.split("/").pop() || predicate.split("#").pop() || predicate,
              })
            }
          }
        })
      } else {
        // Créer un graphe centré sur les résultats
        bindings.forEach((row, rowIndex) => {
          const resultId = `result_${rowIndex}`

          // Ajouter le nœud de résultat
          nodes.push({
            id: resultId,
            name: `Résultat ${rowIndex + 1}`,
            color: "#4cc9f0",
            size: 15,
          })

          // Ajouter un nœud pour chaque valeur et le connecter au résultat
          vars.forEach((varName) => {
            if (row[varName]) {
              const value = row[varName].value
              const valueId = `${varName}_${value}_${rowIndex}`

              // Ajouter le nœud de valeur
              nodes.push({
                id: valueId,
                name: value.split("/").pop() || value.split("#").pop() || value,
                color: row[varName].type === "uri" ? "#7209b7" : "#f72585",
                size: 8,
              })

              // Connecter le résultat à la valeur
              links.push({
                source: resultId,
                target: valueId,
                name: varName,
              })
            }
          })
        })
      }

      console.log(`Created simple graph with ${nodes.length} nodes and ${links.length} links`)
      const newGraphData = { nodes, links }

      // Mettre à jour l'état
      setGraphData(newGraphData)

      // Notifier le parent des données du graphe mises à jour
      if (onGraphDataUpdate) {
        onGraphDataUpdate(newGraphData)
      }
    } catch (error) {
      console.error("Error creating simple graph:", error)
      const newGraphData = { nodes: [], links: [] }
      setGraphData(newGraphData)
      if (onGraphDataUpdate) {
        onGraphDataUpdate(newGraphData)
      }
    }
  }, [results, isBrowser, onGraphDataUpdate]) // Retirer graphData des dépendances

  if (!isBrowser || !results || graphData.nodes.length === 0) {
    return (
      <div className="flex items-center justify-center h-[300px] bg-slate-50 dark:bg-slate-800 rounded-lg border border-dashed">
        <p className="text-slate-500">Aucune donnée à visualiser</p>
      </div>
    )
  }

  return (
    <div className="h-[300px] border rounded-lg overflow-hidden">
      <ForceGraph2D
        ref={graphRef}
        graphData={graphData}
        nodeLabel="name"
        linkLabel="name"
        nodeColor="color"
        nodeVal="size"
        linkDirectionalArrowLength={3}
        linkDirectionalArrowRelPos={1}
        backgroundColor="#ffffff"
        linkColor={() => "#4cc9f0"}
      />
    </div>
  )
}
