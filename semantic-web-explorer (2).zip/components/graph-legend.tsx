"use client"

export function GraphLegend() {
  const legendItems = [
    { color: "#7209b7", label: "Sujet" },
    { color: "#4361ee", label: "Objet" },
    { color: "#f72585", label: "Valeur" },
    { color: "#4cc9f0", label: "Résultat" },
  ]

  return (
    <div className="flex flex-wrap gap-3 p-2 bg-white/80 dark:bg-slate-800/80 rounded-md">
      {legendItems.map((item, index) => (
        <div key={index} className="flex items-center">
          <div className="w-3 h-3 rounded-full mr-1" style={{ backgroundColor: item.color }} />
          <span className="text-xs text-slate-700 dark:text-slate-300">{item.label}</span>
        </div>
      ))}
    </div>
  )
}
