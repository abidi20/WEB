"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { useClientRdfStore } from "@/lib/rdf-store"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Globe, Database, CheckCircle2, AlertCircle, Info, Shield, LogOut } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useBrowser } from "@/hooks/use-browser"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"

export function EndpointConnector() {
  const { toast } = useToast()
  const { connectToEndpoint, currentEndpoint, disconnectEndpoint } = useClientRdfStore()
  const [endpointUrl, setEndpointUrl] = useState("")
  const [isConnecting, setIsConnecting] = useState(false)
  const [selectedPreset, setSelectedPreset] = useState("")
  const [error, setError] = useState("")
  const [errorDetails, setErrorDetails] = useState("")
  const [useCorsProxy, setUseCorsProxy] = useState(false)
  const isBrowser = useBrowser()
  const [showAlternatives, setShowAlternatives] = useState(false)
  const router = useRouter()

  const presetEndpoints = [
    { name: "DBpedia", url: "https://dbpedia.org/sparql", description: "Base de connaissances extraite de Wikipedia" },
    {
      name: "Wikidata",
      url: "https://query.wikidata.org/sparql",
      description: "Base de connaissances structurées collaborative",
    },
    { name: "Bio2RDF", url: "http://bio2rdf.org/sparql", description: "Données biologiques liées" },
    {
      name: "LinkedGeoData",
      url: "http://linkedgeodata.org/sparql",
      description: "Données géographiques d'OpenStreetMap",
    },
  ]

  const handlePresetChange = (value) => {
    setSelectedPreset(value)
    const preset = presetEndpoints.find((p) => p.name === value)
    if (preset) {
      setEndpointUrl(preset.url)
      setError("") // Réinitialiser les erreurs précédentes
      setErrorDetails("")
    }
  }

  const handleConnect = async () => {
    if (!isBrowser) {
      toast({
        title: "Erreur",
        description: "Cette fonctionnalité n'est disponible que dans le navigateur.",
        variant: "destructive",
      })
      return
    }

    if (!endpointUrl.trim()) {
      toast({
        title: "URL vide",
        description: "Veuillez entrer une URL d'endpoint SPARQL.",
        variant: "destructive",
      })
      return
    }

    setIsConnecting(true)
    setError("") // Réinitialiser les erreurs précédentes
    setErrorDetails("")
    setShowAlternatives(false)

    try {
      // Automatically use CORS proxy for known public endpoints or if user has enabled it
      const useProxy = useCorsProxy || endpointUrl.includes("dbpedia.org") || endpointUrl.includes("wikidata.org")

      // Normaliser l'URL de l'endpoint
      let normalizedUrl = endpointUrl.trim()

      // S'assurer que l'URL commence par http:// ou https://
      if (!normalizedUrl.startsWith("http://") && !normalizedUrl.startsWith("https://")) {
        normalizedUrl = "https://" + normalizedUrl
      }

      // Supprimer les paramètres de requête existants s'il y en a
      if (normalizedUrl.includes("?")) {
        normalizedUrl = normalizedUrl.split("?")[0]
      }

      // Show a toast to inform the user we're trying to connect
      toast({
        title: "Connexion en cours",
        description: useProxy
          ? "Tentative de connexion via un proxy CORS..."
          : "Tentative de connexion directe à l'endpoint...",
      })

      await connectToEndpoint(normalizedUrl, useProxy)

      toast({
        title: "Connecté",
        description: `Connexion réussie à ${normalizedUrl}`,
      })

      // Mettre à jour l'URL affichée avec l'URL normalisée
      setEndpointUrl(normalizedUrl)
    } catch (error) {
      console.error("Connection error:", error)

      // Extraire le message d'erreur principal
      const errorMessage = error.message || "Erreur de connexion à l'endpoint SPARQL"

      // Check for specific error types
      const isForbidden = errorMessage.includes("403") || errorMessage.includes("forbidden")
      const isBadRequest = errorMessage.includes("400") || errorMessage.includes("Bad Request")
      const isNetworkError =
        errorMessage.includes("Failed to fetch") ||
        errorMessage.includes("Network error") ||
        errorMessage.includes("TypeError")
      const isCorsError =
        errorMessage.includes("CORS") ||
        errorMessage.includes("cross-origin") ||
        errorMessage.includes("Cross-Origin") ||
        errorMessage.includes("blocked by CORS policy")
      const isTimeout = errorMessage.includes("timed out") || errorMessage.includes("timeout")

      // Set appropriate error message based on error type
      if (isBadRequest) {
        setError("Erreur 400 Bad Request: La requête de test est peut-être mal formatée")
        setErrorDetails(
          "L'endpoint a rejeté la requête de test. Cela peut être dû à une incompatibilité de format ou à des restrictions spécifiques de l'endpoint. Essayez un autre endpoint ou modifiez les paramètres de connexion.",
        )
        setShowAlternatives(true)
      } else if (isForbidden) {
        setError("Erreur 403 Forbidden: L'endpoint refuse l'accès")
        setErrorDetails(
          "L'endpoint refuse l'accès, possiblement en raison de restrictions d'authentification, de limitations d'IP, ou de blocage des serveurs proxy. Essayez un autre endpoint ou chargez des données locales.",
        )
        setShowAlternatives(true)
      } else if (isNetworkError) {
        setError("Erreur réseau: Impossible de se connecter à l'endpoint")
        setErrorDetails(
          "Vérifiez que l'URL est correcte, que votre connexion internet fonctionne, et que l'endpoint est accessible. Si le problème persiste, essayez d'activer l'option 'Utiliser un proxy CORS'.",
        )

        // If not already using a proxy, suggest enabling it
        if (!useCorsProxy) {
          setUseCorsProxy(true)
        }
      } else if (isCorsError) {
        setError("Erreur CORS: L'endpoint n'autorise pas les requêtes depuis cette origine")
        setErrorDetails(
          "L'endpoint bloque les requêtes cross-origin. Activez l'option 'Utiliser un proxy CORS' ci-dessous pour contourner cette restriction.",
        )

        // If not already using a proxy, enable it
        if (!useCorsProxy) {
          setUseCorsProxy(true)
        }
      } else if (isTimeout) {
        setError("Délai d'attente dépassé: L'endpoint ne répond pas")
        setErrorDetails(
          "L'endpoint est peut-être indisponible ou trop lent pour répondre. Essayez un autre endpoint ou réessayez plus tard.",
        )
        setShowAlternatives(true)
      } else {
        setError(errorMessage)
        setErrorDetails("Vérifiez que l'URL est correcte et que l'endpoint est accessible.")
      }

      // Show appropriate toast based on error type
      if (isForbidden) {
        toast({
          title: "Accès refusé à l'endpoint",
          description: "Nous vous recommandons de charger des données RDF locales plutôt que d'utiliser cet endpoint.",
          variant: "destructive",
          duration: 5000,
        })
      } else if (isNetworkError || isCorsError) {
        if (!useCorsProxy) {
          toast({
            title: "Erreur de connexion",
            description: "Proxy CORS activé automatiquement. Essayez de vous connecter à nouveau.",
            variant: "warning",
            duration: 5000,
          })
        } else {
          toast({
            title: "Erreur de connexion",
            description:
              "Impossible de se connecter même avec le proxy CORS. Essayez un autre endpoint ou chargez des données locales.",
            variant: "destructive",
            duration: 5000,
          })
          setShowAlternatives(true)
        }
      } else {
        toast({
          title: "Erreur de connexion",
          description: errorMessage,
          variant: "destructive",
        })
      }
    } finally {
      setIsConnecting(false)
    }
  }

  // Fonction pour se déconnecter de l'endpoint
  const handleDisconnect = () => {
    disconnectEndpoint()
    toast({
      title: "Déconnecté",
      description: "Vous avez été déconnecté de l'endpoint SPARQL.",
    })
  }

  return (
    <Card className="glass card-hover border-white/20 dark:border-slate-700/50 shadow-lg">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl font-bold bg-semantic-gradient bg-clip-text text-transparent flex items-center">
          <div className="h-10 w-10 rounded-full bg-semantic-teal/10 flex items-center justify-center mr-3 glow">
            <Globe className="h-6 w-6 text-semantic-teal" />
          </div>
          Connecteur d'Endpoint SPARQL
        </CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-300">
          Connectez-vous à un endpoint SPARQL distant pour interroger et explorer les données
          {currentEndpoint && (
            <div className="mt-2 flex items-center">
              <Badge className="bg-semantic-green text-white shadow-glow-sm animate-pulse-slow">
                <CheckCircle2 className="h-3 w-3 mr-1" />
                Connecté
              </Badge>
              <span className="ml-2 text-sm font-medium">{currentEndpoint}</span>

              {/* Bouton de déconnexion */}
              <Button
                variant="outline"
                size="sm"
                onClick={handleDisconnect}
                className="ml-auto bg-red-50 hover:bg-red-100 text-red-600 border-red-200"
              >
                <LogOut className="h-3 w-3 mr-1" />
                Déconnecter
              </Button>
            </div>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert
            variant="destructive"
            className="border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-800/30 animated-border"
          >
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Erreur de connexion</AlertTitle>
            <AlertDescription>
              {error}
              {errorDetails && (
                <div className="mt-2 text-sm flex items-start gap-1">
                  <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>{errorDetails}</span>
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        {showAlternatives && (
          <div className="mt-4 p-4 rounded-lg border border-amber-200 bg-amber-50 dark:bg-amber-900/20 dark:border-amber-800/30">
            <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-amber-500" />
              Endpoints alternatifs recommandés
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 mb-2">
              L'endpoint actuel refuse l'accès. Essayez l'un de ces endpoints publics qui sont généralement plus
              accessibles:
            </p>
            <div className="space-y-2 mt-3">
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start text-left"
                onClick={() => {
                  setEndpointUrl("https://query.wikidata.org/sparql")
                  setSelectedPreset("Wikidata")
                  setShowAlternatives(false)
                }}
              >
                <Database className="h-3.5 w-3.5 mr-2" />
                Wikidata SPARQL (https://query.wikidata.org/sparql)
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start text-left"
                onClick={() => {
                  setEndpointUrl("https://dbpedia.org/sparql")
                  setSelectedPreset("DBpedia")
                  setShowAlternatives(false)
                }}
              >
                <Database className="h-3.5 w-3.5 mr-2" />
                DBpedia SPARQL (https://dbpedia.org/sparql)
              </Button>
            </div>
          </div>
        )}

        <div className="grid w-full items-center gap-2">
          <label
            htmlFor="preset-endpoint"
            className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2"
          >
            <Database className="h-4 w-4 text-semantic-purple" />
            Endpoints Prédéfinis
          </label>
          <Select value={selectedPreset} onValueChange={handlePresetChange}>
            <SelectTrigger
              id="preset-endpoint"
              className="bg-white/70 dark:bg-slate-800/70 border-slate-200/50 dark:border-slate-700/50 backdrop-blur-sm"
            >
              <SelectValue placeholder="Sélectionner un endpoint prédéfini" />
            </SelectTrigger>
            <SelectContent>
              {presetEndpoints.map((preset) => (
                <SelectItem key={preset.name} value={preset.name}>
                  <div className="flex flex-col">
                    <span className="font-medium">{preset.name}</span>
                    <span className="text-xs text-slate-500 dark:text-slate-400">{preset.description}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid w-full items-center gap-2">
          <label
            htmlFor="endpoint-url"
            className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2"
          >
            <Globe className="h-4 w-4 text-semantic-blue" />
            URL de l'Endpoint SPARQL
          </label>
          <div className="flex items-center">
            <div className="bg-slate-100/70 dark:bg-slate-700/70 p-2 rounded-l-md border border-r-0 border-slate-200/50 dark:border-slate-600/50 backdrop-blur-sm">
              <Database className="h-5 w-5 text-slate-500 dark:text-slate-400" />
            </div>
            <Input
              id="endpoint-url"
              placeholder="https://example.org/sparql"
              value={endpointUrl}
              onChange={(e) => setEndpointUrl(e.target.value)}
              className="rounded-l-none bg-white/70 dark:bg-slate-800/70 border-slate-200/50 dark:border-slate-700/50 backdrop-blur-sm"
            />
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Switch id="use-cors-proxy" checked={useCorsProxy} onCheckedChange={setUseCorsProxy} />
          <Label htmlFor="use-cors-proxy" className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-semantic-purple" />
            <span>Utiliser un proxy CORS</span>
            <Badge variant="outline" className="ml-1 text-xs">
              Recommandé
            </Badge>
          </Label>
        </div>

        <div className="p-4 rounded-lg border border-slate-200/50 dark:border-slate-700/50 bg-white/30 dark:bg-slate-800/30 backdrop-blur-sm">
          <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
            <div className="h-5 w-5 rounded-full bg-semantic-blue/10 flex items-center justify-center">
              <Globe className="h-3 w-3 text-semantic-blue" />
            </div>
            Qu'est-ce qu'un endpoint SPARQL?
          </h4>
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Un endpoint SPARQL est un service web qui permet d'interroger une base de données RDF en utilisant le
            langage de requête SPARQL. Il vous donne accès à de vastes ensembles de données du Web Sémantique sans avoir
            à les télécharger localement.
          </p>
          <div className="mt-2 text-xs text-slate-600 dark:text-slate-300">
            <p className="font-medium">Note sur les erreurs CORS:</p>
            <p>
              Certains endpoints SPARQL peuvent bloquer les requêtes provenant d'applications web en raison des
              restrictions CORS. Si vous rencontrez des erreurs CORS, activez l'option "Utiliser un proxy CORS" pour
              contourner ces restrictions.
            </p>
          </div>
        </div>

        <div className="mt-4 p-4 rounded-lg border border-blue-200/50 dark:border-blue-700/50 bg-blue-50/30 dark:bg-blue-900/20 backdrop-blur-sm">
          <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
            <div className="h-5 w-5 rounded-full bg-semantic-teal/10 flex items-center justify-center">
              <Info className="h-3 w-3 text-semantic-teal" />
            </div>
            Résolution des problèmes de connexion
          </h4>
          <div className="text-xs text-slate-600 dark:text-slate-300 space-y-2">
            <p>
              <span className="font-medium">Erreurs réseau:</span> Si vous rencontrez des erreurs "Failed to fetch" ou
              "Network error", vérifiez votre connexion internet et assurez-vous que l'URL de l'endpoint est correcte.
            </p>
            <p>
              <span className="font-medium">Erreurs CORS:</span> Les applications web sont souvent limitées par les
              politiques de sécurité du navigateur. L'option "Utiliser un proxy CORS" contourne ces restrictions.
            </p>
            <p>
              <span className="font-medium">Alternative:</span> Si vous ne parvenez pas à vous connecter à un endpoint
              distant, essayez de{" "}
              <Button
                variant="link"
                className="p-0 h-auto text-xs text-semantic-blue dark:text-semantic-teal"
                onClick={() => router.push("/?tab=load")}
              >
                charger des données RDF locales
              </Button>{" "}
              à la place.
            </p>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        {!currentEndpoint ? (
          <Button
            onClick={handleConnect}
            disabled={!endpointUrl.trim() || isConnecting || !isBrowser}
            className="w-full bg-semantic-gradient hover:opacity-90 transition-opacity shadow-glow-sm"
          >
            {isConnecting ? (
              <div className="flex items-center gap-2">
                <div className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                <span>Connexion en cours...</span>
              </div>
            ) : (
              "Se connecter à l'Endpoint"
            )}
          </Button>
        ) : (
          <Button
            onClick={handleDisconnect}
            className="w-full bg-red-500 hover:bg-red-600 text-white transition-colors"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Déconnecter de l'Endpoint
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
