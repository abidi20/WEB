"use client"

import { useState, useCallback, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { useRdfStore } from "@/lib/rdf-store"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import {
  Play,
  Table2,
  Code,
  Database,
  AlertCircle,
  Network,
  Download,
  FileJson,
  FileText,
  FileSpreadsheet,
  Info,
  HelpCircle,
  BookOpen,
  Clock,
} from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { SimpleGraphView } from "@/components/simple-graph-view"
import { useBrowser } from "@/hooks/use-browser"
import {
  exportAsJson,
  exportAsCsv,
  exportAsTurtle,
  exportAsDot,
  exportAsGraphML,
  exportAsNTriples,
  exportAsJsonLd,
} from "@/lib/export-utils"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SparqlDocumentation } from "@/components/sparql-documentation"
// Ajouter l'import pour le nouveau composant PrefixHelper
import { PrefixHelper } from "@/components/prefix-helper"
import { useRouter } from "next/navigation"
// Ajouter un nouvel import pour le composant QueryHistory
import { QueryHistory } from "@/components/query-history"

export function SparqlEditor() {
  const { toast } = useToast()
  const { executeQuery, currentEndpoint, graph } = useRdfStore()
  // Exemples de requêtes pour différents types
  const queryExamples = {
    select: `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?subject ?predicate ?object
WHERE {
  ?subject ?predicate ?object .
}
LIMIT 10`,

    ask: `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

ASK {
  ?s rdfs:label ?label .
}`,

    construct: `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

CONSTRUCT {
  ?s rdfs:label ?label .
}
WHERE {
  ?s rdfs:label ?label .
}
LIMIT 10`,

    describe: `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

DESCRIBE ?s
WHERE {
  ?s rdfs:label ?label .
}
LIMIT 5`,
  }

  // État pour stocker la requête actuelle
  const [query, setQuery] = useState(queryExamples.select)
  const [results, setResults] = useState(null)
  const [graphData, setGraphData] = useState({ nodes: [], links: [] })
  const [isLoading, setIsLoading] = useState(false)
  const [useReasoning, setUseReasoning] = useState(false)
  const [error, setError] = useState("")
  const [queryType, setQueryType] = useState("SELECT")
  const [showDocumentation, setShowDocumentation] = useState(false)
  // Ajouter un état pour contrôler l'affichage de l'aide aux préfixes
  // Ajouter cette ligne avec les autres déclarations d'état
  const [showPrefixHelper, setShowPrefixHelper] = useState(false)
  const [queryHistory, setQueryHistory] = useState<string[]>([])
  // Ajouter un nouvel état pour contrôler l'affichage de l'historique des requêtes
  // Ajouter avec les autres déclarations useState:
  const [showQueryHistory, setShowQueryHistory] = useState(false)
  const isBrowser = useBrowser()
  const router = useRouter()

  // Ajouter un useEffect pour charger l'historique depuis localStorage au chargement
  // Ajouter après les déclarations useState:
  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        const savedQueries = JSON.parse(localStorage.getItem("sparqlQueryHistory") || "[]")
        if (savedQueries.length > 0) {
          setQueryHistory(savedQueries)
        }
      } catch (e) {
        console.error("Error loading query history from localStorage:", e)
      }
    }
  }, [])

  // Fonction pour télécharger un fichier
  const downloadFile = (content, filename, mimeType) => {
    const blob = new Blob([content], { type: mimeType })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Fonction pour détecter le type de requête
  const detectQueryType = (queryText) => {
    const cleanQuery = queryText
      .replace(/^\s+|\s+$/g, "")
      .replace(/\s+/g, " ")
      .toUpperCase()
    const prefixPattern = /^(PREFIX\s+[^\n]+\s+)*/i
    const withoutPrefixes = cleanQuery.replace(prefixPattern, "")

    if (withoutPrefixes.startsWith("SELECT")) return "SELECT"
    if (withoutPrefixes.startsWith("ASK")) return "ASK"
    if (withoutPrefixes.startsWith("CONSTRUCT")) return "CONSTRUCT"
    if (withoutPrefixes.startsWith("DESCRIBE")) return "DESCRIBE"
    if (withoutPrefixes.includes("INSERT") || withoutPrefixes.includes("DELETE")) return "UPDATE"

    return "UNKNOWN"
  }

  // Fonction pour afficher les résultats
  const renderResults = () => {
    if (!results) {
      return (
        <div className="p-4 text-center text-slate-500">
          Aucun résultat à afficher. Exécutez une requête pour voir les résultats.
        </div>
      )
    }

    // Vérifier si une erreur est présente dans les résultats
    if (results.error) {
      return (
        <Alert variant="destructive" className="m-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Erreur dans les résultats</AlertTitle>
          <AlertDescription>{results.error}</AlertDescription>
        </Alert>
      )
    }

    // Vérifier si c'est une requête ASK (qui retourne un booléen)
    if (results.results && results.results.hasOwnProperty("boolean")) {
      return (
        <div className="p-6 text-center">
          <div className="text-2xl font-bold mb-2">Résultat de la requête ASK</div>
          <div className={`text-3xl font-bold ${results.results.boolean ? "text-green-500" : "text-red-500"}`}>
            {results.results.boolean ? "TRUE" : "FALSE"}
          </div>
        </div>
      )
    }

    // Vérifier si c'est une requête CONSTRUCT ou DESCRIBE (qui retourne du RDF)
    if (results.results && results.results.rdfContent) {
      return (
        <ScrollArea className="h-[400px]">
          <div className="p-4">
            <div className="mb-2 text-sm text-slate-500">Format: {results.results.contentType || "text/turtle"}</div>
            <pre className="text-xs p-4 bg-slate-50 dark:bg-slate-800 rounded-md overflow-auto font-mono whitespace-pre-wrap">
              {results.results.rdfContent}
            </pre>
          </div>
        </ScrollArea>
      )
    }

    // Vérifier si c'est un contenu brut
    if (results.results && results.results.rawContent) {
      return (
        <ScrollArea className="h-[400px]">
          <div className="p-4">
            <div className="mb-2 text-sm text-slate-500">Format: {results.results.contentType || "text/plain"}</div>
            <pre className="text-xs p-4 bg-slate-50 dark:bg-slate-800 rounded-md overflow-auto font-mono whitespace-pre-wrap">
              {results.results.rawContent}
            </pre>
          </div>
        </ScrollArea>
      )
    }

    // Traitement standard pour les requêtes SELECT
    if (!results.head || !results.results || !results.results.bindings) {
      return <div className="p-4 text-center text-slate-500">Format de résultats non reconnu.</div>
    }

    const {
      head,
      results: { bindings },
    } = results
    const vars = head.vars || []

    if (bindings.length === 0) {
      return <div className="p-4 text-center text-slate-500">La requête n'a retourné aucun résultat.</div>
    }

    return (
      <ScrollArea className="h-[400px]">
        <Table>
          <TableHeader>
            <TableRow>
              {vars.map((variable, index) => (
                <TableHead key={index}>{variable}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {bindings.map((row, rowIndex) => (
              <TableRow key={rowIndex}>
                {vars.map((variable, varIndex) => (
                  <TableCell key={varIndex}>
                    {row[variable] ? (
                      <div>
                        <span>{row[variable].value}</span>
                        {row[variable].type && (
                          <Badge variant="outline" className="ml-1 text-xs">
                            {row[variable].type}
                          </Badge>
                        )}
                      </div>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </ScrollArea>
    )
  }

  // Fonction pour exporter les résultats
  const handleExportResults = (format) => {
    if (!results) {
      toast({
        title: "Aucun résultat",
        description: "Il n'y a aucun résultat à exporter.",
        variant: "destructive",
      })
      return
    }

    try {
      // Si nous avons du contenu RDF direct (CONSTRUCT/DESCRIBE)
      if (results.results && results.results.rdfContent) {
        // Pour le contenu RDF, nous pouvons l'exporter directement
        const filename = `sparql-results.${format === "turtle" ? "ttl" : format === "ntriples" ? "nt" : "rdf"}`
        downloadFile(results.results.rdfContent, filename, results.results.contentType || "text/turtle")

        toast({
          title: "Exportation réussie",
          description: `Les résultats RDF ont été exportés au format ${format.toUpperCase()}.`,
        })
        return
      }

      // Si nous avons un résultat booléen (ASK)
      if (results.results && results.results.hasOwnProperty("boolean")) {
        let content = ""

        switch (format) {
          case "json":
            content = JSON.stringify({ boolean: results.results.boolean }, null, 2)
            downloadFile(content, "sparql-ask-result.json", "application/json")
            break
          case "turtle":
          case "ntriples":
            content = `@prefix res: <http://example.org/result/> .\nres:result res:hasAnswer "${results.results.boolean}" .`
            downloadFile(content, `sparql-ask-result.${format === "turtle" ? "ttl" : "nt"}`, "text/turtle")
            break
          default:
            content = `ASK query result: ${results.results.boolean}`
            downloadFile(content, "sparql-ask-result.txt", "text/plain")
        }

        toast({
          title: "Exportation réussie",
          description: `Le résultat ASK a été exporté au format ${format.toUpperCase()}.`,
        })
        return
      }

      // Si nous avons un contenu brut
      if (results.results && results.results.rawContent) {
        downloadFile(
          results.results.rawContent,
          `sparql-results.${format}`,
          results.results.contentType || "text/plain",
        )
        toast({
          title: "Exportation réussie",
          description: `Le contenu brut a été exporté.`,
        })
        return
      }

      // Traitement standard pour les résultats SELECT
      switch (format) {
        case "json":
          exportAsJson(results, "sparql-results.json")
          break
        case "csv":
          exportAsCsv(results, "sparql-results.csv")
          break
        case "turtle":
          exportAsTurtle(results, "sparql-results.ttl")
          break
        case "ntriples":
          exportAsNTriples(results, "sparql-results.nt")
          break
        case "jsonld":
          exportAsJsonLd(results, "sparql-results.jsonld")
          break
        default:
          throw new Error(`Format d'exportation non pris en charge: ${format}`)
      }

      toast({
        title: "Exportation réussie",
        description: `Les résultats ont été exportés au format ${format.toUpperCase()}.`,
      })
    } catch (error) {
      console.error("Export error:", error)
      toast({
        title: "Erreur d'exportation",
        description: error.message || "Une erreur s'est produite lors de l'exportation des résultats.",
        variant: "destructive",
      })
    }
  }

  // Fonction pour exporter le graphe
  const handleExportGraph = (format) => {
    if (!graphData || !graphData.nodes || graphData.nodes.length === 0) {
      toast({
        title: "Aucun graphe à exporter",
        description: "Veuillez d'abord générer un graphe.",
        variant: "destructive",
      })
      return
    }

    try {
      switch (format) {
        case "dot":
          exportAsDot(graphData, "sparql-graph.dot")
          break
        case "graphml":
          exportAsGraphML(graphData, "sparql-graph.graphml")
          break
        default:
          throw new Error(`Format d'exportation non pris en charge: ${format}`)
      }

      toast({
        title: "Exportation réussie",
        description: `Le graphe a été exporté au format ${format.toUpperCase()}.`,
      })
    } catch (error) {
      console.error("Graph export error:", error)
      toast({
        title: "Erreur d'exportation du graphe",
        description: error.message || "Une erreur s'est produite lors de l'exportation du graphe.",
        variant: "destructive",
      })
    }
  }

  // Fonction pour sélectionner un exemple de requête depuis la documentation
  const handleSelectExample = (exampleQuery) => {
    setQuery(exampleQuery)
    setShowDocumentation(false)
    toast({
      title: "Exemple sélectionné",
      description: "L'exemple de requête a été chargé dans l'éditeur.",
    })
  }

  // Fonction améliorée pour exécuter la requête
  const handleExecuteQuery = async () => {
    if (!query.trim()) {
      toast({
        title: "Requête vide",
        description: "Veuillez entrer une requête SPARQL à exécuter.",
        variant: "destructive",
      })
      return
    }

    // Vérifier si des données sont disponibles
    if (!graph && !currentEndpoint) {
      toast({
        title: "Aucune source de données",
        description:
          "Veuillez charger des données RDF ou vous connecter à un endpoint SPARQL avant d'exécuter une requête.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    setError("")
    setResults(null) // Réinitialiser les résultats précédents
    setGraphData({ nodes: [], links: [] }) // Réinitialiser les données du graphe

    // Détecter le type de requête
    const detectedType = detectQueryType(query)
    setQueryType(detectedType)
    console.log("Detected query type:", detectedType)

    try {
      // Save query to history if it's not already the most recent one
      // Save query to history if it's not already in the history
      if (!queryHistory.includes(query)) {
        setQueryHistory((prev) => [query, ...prev.slice(0, 9)]) // Keep last 10 queries

        // Save to localStorage if available
        if (typeof window !== "undefined") {
          try {
            const savedQueries = JSON.parse(localStorage.getItem("sparqlQueryHistory") || "[]")
            const updatedQueries = [query, ...savedQueries.filter((q) => q !== query).slice(0, 9)]
            localStorage.setItem("sparqlQueryHistory", JSON.stringify(updatedQueries))
          } catch (e) {
            console.error("Error saving query history to localStorage:", e)
          }
        }
      }

      console.log("Executing query:", query)
      const queryResults = await executeQuery(query, useReasoning)
      console.log("Query results received:", queryResults)

      // Vérifier si les résultats sont vides mais devraient contenir des données
      if (
        detectedType === "SELECT" &&
        queryResults?.results?.bindings &&
        queryResults.results.bindings.length === 0 &&
        query.toLowerCase().includes("foaf:person")
      ) {
        // Suggérer une solution
        toast({
          title: "Résultats vides",
          description:
            "Essayez de charger d'abord des données RDF contenant des définitions FOAF, ou utilisez des données d'exemple intégrées.",
        })
      }

      // Mettre à jour l'état avec les résultats
      setResults(queryResults)
      console.log("Results state updated:", queryResults)

      // Message de succès adapté au type de requête
      let successMessage = ""
      if (detectedType === "ASK") {
        successMessage = `La requête ASK a retourné ${queryResults?.results?.boolean ? "TRUE" : "FALSE"}.`
      } else if (detectedType === "CONSTRUCT" || detectedType === "DESCRIBE") {
        successMessage = "La requête a généré des données RDF."
      } else if (detectedType === "UPDATE") {
        successMessage = "La requête de mise à jour a été exécutée."
      } else {
        successMessage = `La requête a retourné ${queryResults?.results?.bindings?.length || 0} résultats.`
      }

      toast({
        title: "Requête exécutée",
        description: successMessage,
      })
    } catch (error) {
      console.error("Query execution error:", error)

      // Check if the results include a notice about falling back to local data
      if (error.results && error.results.notice) {
        // This is actually a successful result with a notice, not an error
        setResults(error)
        toast({
          title: "Requête exécutée sur les données locales",
          description:
            "L'endpoint a refusé l'accès (403 Forbidden), mais la requête a été exécutée avec succès sur les données locales.",
          variant: "warning",
        })
        return
      }

      // Améliorer les messages d'erreur pour les problèmes courants
      const errorMessage = error.message || "Une erreur s'est produite lors de l'exécution de la requête."

      // Détection plus précise des types d'erreurs
      const isForbidden = errorMessage.includes("403") || errorMessage.includes("forbidden")
      const isBadRequest = errorMessage.includes("400") || errorMessage.includes("Bad Request")
      const isCorsError = errorMessage.includes("CORS") || errorMessage.includes("cross-origin")
      const isNetworkError = errorMessage.includes("Failed to fetch") || errorMessage.includes("Network")

      // Message d'erreur adapté au type d'erreur
      let userFriendlyMessage = errorMessage

      if (isBadRequest) {
        userFriendlyMessage =
          "Erreur 400 Bad Request: La requête SPARQL est peut-être mal formatée ou contient une syntaxe incorrecte."
        setError(userFriendlyMessage)

        toast({
          title: "Erreur de requête",
          description: "Vérifiez la syntaxe de votre requête SPARQL. L'endpoint a signalé une erreur de format.",
          variant: "destructive",
        })
      } else if (isForbidden) {
        setError(errorMessage)

        // Check if we have local data available
        if (graph && graph.size > 0) {
          toast({
            title: "Erreur d'accès à l'endpoint (403 Forbidden)",
            description:
              "L'endpoint SPARQL refuse l'accès. Essayez d'utiliser les données locales en cliquant sur le bouton ci-dessous.",
            variant: "warning",
            duration: 5000,
          })

          // Add a button to try executing the query on local data
          const tryLocalButton = document.createElement("button")
          tryLocalButton.innerText = "Exécuter sur les données locales"
          tryLocalButton.className = "px-4 py-2 mt-2 bg-semantic-purple text-white rounded-md hover:bg-opacity-90"
          tryLocalButton.onclick = async () => {
            try {
              setIsLoading(true)
              // Force execution on local data by temporarily disconnecting the endpoint
              const tempEndpoint = currentEndpoint
              useRdfStore.setState({ currentEndpoint: null })

              const localResults = await executeQuery(query, useReasoning)

              // Restore the endpoint
              useRdfStore.setState({ currentEndpoint: tempEndpoint })

              setResults(localResults)
              setIsLoading(false)
              toast({
                title: "Requête exécutée sur les données locales",
                description: `La requête a retourné ${localResults?.results?.bindings?.length || 0} résultats.`,
              })
            } catch (localError) {
              console.error("Local execution error:", localError)
              setIsLoading(false)
              toast({
                title: "Erreur d'exécution locale",
                description:
                  localError.message ||
                  "Une erreur s'est produite lors de l'exécution de la requête sur les données locales.",
                variant: "destructive",
              })
            }
          }

          // Find a good place to add the button
          const alertContainer = document.querySelector(".alert-description")
          if (alertContainer) {
            alertContainer.appendChild(tryLocalButton)
          }
        } else {
          // Show a more helpful toast with specific guidance
          toast({
            title: "Erreur d'accès à l'endpoint (403 Forbidden)",
            description: "L'endpoint SPARQL refuse l'accès. Nous vous recommandons de charger des données RDF locales.",
            variant: "destructive",
            duration: 5000, // Show for longer
          })
        }
      } else if (isCorsError) {
        setError("Erreur CORS: L'endpoint n'autorise pas les requêtes depuis cette origine")
        toast({
          title: "Erreur CORS",
          description: "Essayez d'utiliser un proxy CORS ou de charger des données locales.",
          variant: "destructive",
        })
      } else if (isNetworkError) {
        setError("Erreur réseau: Impossible de se connecter à l'endpoint")
        toast({
          title: "Erreur de connexion",
          description: "Vérifiez votre connexion internet et l'URL de l'endpoint.",
          variant: "destructive",
        })
      } else {
        setError(errorMessage)
        toast({
          title: "Erreur de requête",
          description: errorMessage,
          variant: "destructive",
        })
      }
    } finally {
      setIsLoading(false)
    }
  }

  // Fonction simplifiée pour afficher les résultats bruts
  const renderRawResults = () => {
    if (!results) return null

    return (
      <pre className="text-xs p-4 bg-slate-50 dark:bg-slate-800 rounded-md overflow-auto font-mono">
        {JSON.stringify(results, null, 2)}
      </pre>
    )
  }

  // Utiliser useCallback pour éviter les recréations de fonction à chaque rendu
  const updateGraphData = useCallback((data) => {
    setGraphData(data)
  }, [])

  // Ajouter une fonction pour gérer l'ajout de préfixes
  // Ajouter cette fonction après updateGraphData
  const handleAddPrefix = (prefixDeclaration) => {
    // Ajouter le préfixe au début de la requête
    setQuery(prefixDeclaration + query)
  }

  return (
    <div className="grid grid-cols-1 gap-6">
      {showDocumentation ? (
        <>
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Documentation SPARQL</h2>
            <Button variant="outline" onClick={() => setShowDocumentation(false)}>
              Retour à l'éditeur
            </Button>
          </div>
          <SparqlDocumentation onSelectExample={handleSelectExample} />
        </>
      ) : (
        <>
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-2xl font-bold">Éditeur de Requêtes SPARQL</CardTitle>
                  <CardDescription>
                    Écrivez et exécutez des requêtes SPARQL sur vos données RDF ou endpoint connecté
                    {currentEndpoint && (
                      <Badge className="ml-2 bg-blue-500 text-white">
                        <Database className="h-3 w-3 mr-1" />
                        {currentEndpoint}
                      </Badge>
                    )}
                  </CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowDocumentation(true)}
                    className="flex items-center gap-1"
                  >
                    <BookOpen className="h-4 w-4" />
                    Documentation
                  </Button>
                  <div className="flex items-center ml-4">
                    <Switch id="reasoning" checked={useReasoning} onCheckedChange={setUseReasoning} />
                    <Label htmlFor="reasoning" className="text-sm ml-2">
                      Activer le raisonnement OWL
                    </Label>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Erreur d'exécution</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              {error && error.includes("403") && (
                <Alert
                  variant="warning"
                  className="mt-2 mb-4 bg-amber-50 border-amber-200 text-amber-800 dark:bg-amber-900/20 dark:border-amber-800/30 dark:text-amber-300"
                >
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Problème d'accès à l'endpoint SPARQL</AlertTitle>
                  <AlertDescription className="space-y-2">
                    <p>
                      L'endpoint SPARQL a retourné une erreur 403 Forbidden, ce qui signifie qu'il refuse l'accès à
                      notre application. Cela peut être dû à:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Des restrictions d'authentification sur l'endpoint</li>
                      <li>Des limitations d'accès basées sur l'IP</li>
                      <li>Le blocage des requêtes provenant de proxies CORS</li>
                    </ul>
                    <p className="font-medium mt-2">Solutions recommandées:</p>
                    <div className="flex flex-col gap-2 mt-1">
                      <Button
                        variant="outline"
                        size="sm"
                        className="justify-start bg-white/50 dark:bg-slate-800/50 border-amber-200 dark:border-amber-800/30"
                        onClick={() => router.push("/?tab=load")}
                      >
                        <FileText className="h-4 w-4 mr-2 text-amber-600 dark:text-amber-400" />
                        Charger des données RDF locales
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="justify-start bg-white/50 dark:bg-slate-800/50 border-amber-200 dark:border-amber-800/30"
                        onClick={() => router.push("/?tab=endpoints")}
                      >
                        <Database className="h-4 w-4 mr-2 text-amber-600 dark:text-amber-400" />
                        Essayer un autre endpoint SPARQL
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              )}

              <div className="mb-4">
                <Label className="mb-2 block">Exemples de requêtes</Label>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuery(queryExamples.select)}
                    className={query === queryExamples.select ? "bg-semantic-purple text-white" : ""}
                  >
                    SELECT
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuery(queryExamples.ask)}
                    className={query === queryExamples.ask ? "bg-semantic-purple text-white" : ""}
                  >
                    ASK
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuery(queryExamples.construct)}
                    className={query === queryExamples.construct ? "bg-semantic-purple text-white" : ""}
                  >
                    CONSTRUCT
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuery(queryExamples.describe)}
                    className={query === queryExamples.describe ? "bg-semantic-purple text-white" : ""}
                  >
                    DESCRIBE
                  </Button>
                  {/* Remplacer le contenu du DropdownMenu de l'historique par un lien vers le nouveau composant */}
                  {/* Chercher le DropdownMenu avec "Historique" et remplacer par: */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowPrefixHelper(false)}
                    className={showQueryHistory ? "bg-semantic-purple text-white" : ""}
                    onMouseDown={() => setShowQueryHistory(!showQueryHistory)}
                  >
                    <Clock className="h-4 w-4 mr-1" />
                    Historique
                  </Button>
                  {/* Modifier le bouton d'aide dans la section des exemples de requêtes */}
                  {/* Chercher le bouton avec <HelpCircle className="h-4 w-4 mr-1" /> et remplacer par: */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowPrefixHelper(!showPrefixHelper)}
                    className="ml-auto"
                  >
                    <HelpCircle className="h-4 w-4 mr-1" />
                    Préfixes
                  </Button>
                </div>
              </div>

              {/* Ajouter le composant PrefixHelper après le Textarea de la requête */}
              {/* Chercher le Textarea et ajouter après: */}
              <Textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="font-mono h-[200px] mb-4"
                placeholder="Entrez votre requête SPARQL ici..."
              />

              {showPrefixHelper && (
                <div className="mb-4">
                  <PrefixHelper onAddPrefix={handleAddPrefix} />
                </div>
              )}
              {/* Ajouter le composant QueryHistory après le composant PrefixHelper */}
              {/* Chercher la ligne "{showPrefixHelper && (" et ajouter après le bloc fermant ")}": */}
              {showQueryHistory && (
                <div className="mb-4">
                  <QueryHistory
                    queries={queryHistory}
                    onSelectQuery={setQuery}
                    onClearHistory={() => {
                      setQueryHistory([])
                      if (typeof window !== "undefined") {
                        localStorage.removeItem("sparqlQueryHistory")
                      }
                      toast({
                        title: "Historique effacé",
                        description: "L'historique des requêtes a été effacé.",
                      })
                    }}
                  />
                </div>
              )}
              <Button onClick={handleExecuteQuery} disabled={isLoading} className="w-full">
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                    <span>Exécution en cours...</span>
                  </div>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Exécuter la requête
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-2xl font-bold bg-semantic-gradient-alt bg-clip-text text-transparent">
                    Résultats de la Requête
                  </CardTitle>
                  {queryType && (
                    <Badge className="mt-1 bg-semantic-purple text-white">
                      <Info className="h-3 w-3 mr-1" />
                      Type: {queryType}
                    </Badge>
                  )}
                </div>
                {results && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-1" />
                        Exporter
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem onClick={() => handleExportResults("json")}>
                        <FileJson className="h-4 w-4 mr-2" />
                        <span>JSON</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleExportResults("csv")}>
                        <FileSpreadsheet className="h-4 w-4 mr-2" />
                        <span>CSV</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleExportResults("turtle")}>
                        <FileText className="h-4 w-4 mr-2" />
                        <span>Turtle (.ttl)</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleExportResults("ntriples")}>
                        <FileText className="h-4 w-4 mr-2" />
                        <span>N-Triples (.nt)</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleExportResults("jsonld")}>
                        <FileJson className="h-4 w-4 mr-2" />
                        <span>JSON-LD</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="tableau" className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-4">
                  <TabsTrigger value="tableau" className="flex items-center gap-2">
                    <Table2 className="h-4 w-4" />
                    Vue Tableau
                  </TabsTrigger>
                  <TabsTrigger value="graphe" className="flex items-center gap-2">
                    <Network className="h-4 w-4" />
                    Vue Graphe
                  </TabsTrigger>
                  <TabsTrigger value="json" className="flex items-center gap-2">
                    <Code className="h-4 w-4" />
                    JSON Brut
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="tableau" className="border rounded-lg">
                  {renderResults()}
                </TabsContent>

                <TabsContent value="graphe">
                  {isBrowser && results && (
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="text-lg font-semibold flex items-center">
                          <Network className="h-5 w-5 mr-2" />
                          Visualisation Graphique
                        </h3>
                        {graphData.nodes && graphData.nodes.length > 0 && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="outline" size="sm">
                                <Download className="h-4 w-4 mr-1" />
                                Exporter le Graphe
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              <DropdownMenuItem onClick={() => handleExportGraph("dot")}>
                                <FileText className="h-4 w-4 mr-2" />
                                <span>DOT (Graphviz)</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleExportGraph("graphml")}>
                                <FileText className="h-4 w-4 mr-2" />
                                <span>GraphML</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </div>
                      <SimpleGraphView results={results} onGraphDataUpdate={updateGraphData} />
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="json">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-lg font-semibold flex items-center">
                      <Code className="h-5 w-5 mr-2" />
                      Résultats bruts (JSON)
                    </h3>
                    {results && (
                      <Button variant="outline" size="sm" onClick={() => handleExportResults("json")}>
                        <Download className="h-4 w-4 mr-1" />
                        Télécharger JSON
                      </Button>
                    )}
                  </div>
                  {renderRawResults()}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
