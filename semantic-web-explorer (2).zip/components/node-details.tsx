"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useRdfStore } from "@/lib/rdf-store"
import { Hash, Key, Tag, AlertCircle } from "lucide-react"
import { NodeLink } from "@/components/node-link"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useBrowser } from "@/hooks/use-browser"

export function NodeDetails() {
  const { selectedNode, cbd } = useRdfStore()
  const [nodeProperties, setNodeProperties] = useState([])
  const [nodeRelations, setNodeRelations] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const isBrowser = useBrowser()

  useEffect(() => {
    // All browser-only code should be here
    if (!isBrowser) return

    if (selectedNode) {
      setLoading(true)
      setError("")

      try {
        console.log("Selected node:", selectedNode)
        console.log("CBD data:", cbd)

        // Process CBD to extract properties and relations
        const properties = []
        const relations = []

        if (cbd && cbd.length > 0) {
          cbd.forEach((quad) => {
            if (quad.subject.value === selectedNode) {
              if (quad.object.termType === "Literal") {
                properties.push({
                  predicate: quad.predicate.value,
                  predicateName:
                    quad.predicate.value.split("/").pop() ||
                    quad.predicate.value.split("#").pop() ||
                    quad.predicate.value,
                  value: quad.object.value,
                  datatype: quad.object.datatype?.value,
                })
              } else {
                relations.push({
                  predicate: quad.predicate.value,
                  predicateName:
                    quad.predicate.value.split("/").pop() ||
                    quad.predicate.value.split("#").pop() ||
                    quad.predicate.value,
                  object: quad.object.value,
                  objectName:
                    quad.object.value.split("/").pop() || quad.object.value.split("#").pop() || quad.object.value,
                })
              }
            }
          })
        }

        console.log("Processed properties:", properties.length)
        console.log("Processed relations:", relations.length)

        setNodeProperties(properties)
        setNodeRelations(relations)
      } catch (err) {
        console.error("Error processing CBD:", err)
        setError("Erreur lors du traitement des données du nœud")
      } finally {
        setLoading(false)
      }
    } else {
      setNodeProperties([])
      setNodeRelations([])
      setLoading(false)
      setError("")
    }
  }, [cbd, selectedNode, isBrowser])

  const nodeName = selectedNode ? selectedNode.split("/").pop() || selectedNode.split("#").pop() || selectedNode : null

  return (
    <Card className="h-full border border-slate-200 dark:border-slate-700 shadow-lg bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl font-bold text-semantic-pink">Détails du Nœud</CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-300">
          Description Concise Bornée (CBD)
        </CardDescription>
      </CardHeader>
      <CardContent className="h-[500px] pt-2">
        {selectedNode ? (
          <div className="space-y-4">
            <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
              <div className="flex items-center gap-2 mb-1">
                <Hash className="h-4 w-4 text-semantic-purple" />
                <h3 className="font-semibold text-lg">{nodeName}</h3>
              </div>
              <Badge
                variant="outline"
                className="text-xs break-all w-full justify-start h-auto py-1 px-2 font-mono bg-white dark:bg-slate-800"
              >
                {selectedNode}
              </Badge>
            </div>

            {loading && (
              <div className="flex justify-center py-4">
                <div className="h-8 w-8 rounded-full border-4 border-semantic-purple border-t-transparent animate-spin"></div>
              </div>
            )}

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <ScrollArea className="h-[350px] pr-4">
              {!loading && nodeProperties.length === 0 && nodeRelations.length === 0 && (
                <div className="p-4 text-center text-slate-500 dark:text-slate-400">
                  <p>Aucune propriété ou relation trouvée pour ce nœud.</p>
                  <p className="text-sm mt-2">
                    Cela peut être dû au fait que le nœud n'a pas de propriétés ou de relations dans le graphe, ou que
                    les données n'ont pas été correctement chargées.
                  </p>
                </div>
              )}

              {nodeProperties.length > 0 && (
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Key className="h-4 w-4 text-semantic-pink" />
                    <h4 className="font-semibold text-base">Propriétés</h4>
                  </div>
                  <ul className="space-y-3">
                    {nodeProperties.map((prop, index) => (
                      <li
                        key={index}
                        className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <span className="text-sm font-medium text-semantic-blue dark:text-semantic-teal">
                          {prop.predicateName}
                        </span>
                        <p className="text-sm mt-1 break-words">{prop.value}</p>
                        {prop.datatype && (
                          <Badge
                            variant="secondary"
                            className="text-xs mt-1 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300"
                          >
                            {prop.datatype.split("/").pop() || prop.datatype.split("#").pop() || prop.datatype}
                          </Badge>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {nodeRelations.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Tag className="h-4 w-4 text-semantic-green" />
                    <h4 className="font-semibold text-base">Relations</h4>
                  </div>
                  <ul className="space-y-3">
                    {nodeRelations.map((rel, index) => (
                      <li
                        key={index}
                        className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <span className="text-sm font-medium text-semantic-purple">{rel.predicateName}</span>
                        <div className="flex items-center gap-1 mt-1">
                          <NodeLink nodeUri={rel.object} className="text-sm">
                            {rel.objectName}
                          </NodeLink>
                        </div>
                        <Badge
                          variant="outline"
                          className="text-xs mt-1 break-all w-full justify-start h-auto py-1 px-2 font-mono"
                        >
                          {rel.object}
                        </Badge>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </ScrollArea>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-dashed border-slate-300 dark:border-slate-600">
            <div className="w-16 h-16 mb-4 rounded-full bg-semantic-gradient-alt flex items-center justify-center animate-pulse-slow">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-white"
              >
                <circle cx="12" cy="12" r="10"></circle>
                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                <line x1="12" y1="17" x2="12.01" y2="17"></line>
              </svg>
            </div>
            <p className="text-slate-600 dark:text-slate-300 text-center max-w-xs">
              Aucun nœud sélectionné. Cliquez sur un nœud dans le graphe pour afficher ses détails.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
