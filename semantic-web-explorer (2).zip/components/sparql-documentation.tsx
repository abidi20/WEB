"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Search, CheckCircle, Database, FileText, PenTool, HelpCircle, Copy } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"

interface SparqlDocumentationProps {
  onSelectExample: (query: string) => void
}

export function SparqlDocumentation({ onSelectExample }: SparqlDocumentationProps) {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("select")

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(
      () => {
        toast({
          title: "Copié !",
          description: "La requête a été copiée dans le presse-papiers.",
        })
      },
      (err) => {
        toast({
          title: "Erreur",
          description: "Impossible de copier le texte: " + err,
          variant: "destructive",
        })
      },
    )
  }

  const examples = {
    select: [
      {
        title: "Requête SELECT basique",
        description: "Récupère tous les triplets (limités à 10)",
        query: `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?subject ?predicate ?object
WHERE {
  ?subject ?predicate ?object .
}
LIMIT 10`,
      },
      {
        title: "Requête avec filtres",
        description: "Récupère les ressources avec un label contenant un terme spécifique",
        query: `PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?resource ?label
WHERE {
  ?resource rdfs:label ?label .
  FILTER(CONTAINS(LCASE(?label), "science"))
}
LIMIT 20`,
      },
      {
        title: "Requête avec agrégation",
        description: "Compte le nombre de ressources par type",
        query: `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

SELECT ?type (COUNT(?resource) AS ?count)
WHERE {
  ?resource rdf:type ?type .
}
GROUP BY ?type
ORDER BY DESC(?count)
LIMIT 10`,
      },
    ],
    ask: [
      {
        title: "Requête ASK simple",
        description: "Vérifie si une ressource spécifique existe",
        query: `PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

ASK {
  ?s rdfs:label ?label .
}`,
      },
      {
        title: "Requête ASK avec condition",
        description: "Vérifie si une ressource avec un label spécifique existe",
        query: `PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

ASK {
  ?s rdfs:label "Science"@en .
}`,
      },
    ],
    construct: [
      {
        title: "Requête CONSTRUCT basique",
        description: "Crée un nouveau graphe avec les mêmes triplets",
        query: `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

CONSTRUCT {
  ?s rdfs:label ?label .
}
WHERE {
  ?s rdfs:label ?label .
}
LIMIT 10`,
      },
      {
        title: "Requête CONSTRUCT avec transformation",
        description: "Crée un nouveau graphe en transformant les données",
        query: `PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX ex: <http://example.org/>

CONSTRUCT {
  ?s ex:hasName ?label .
}
WHERE {
  ?s rdfs:label ?label .
}
LIMIT 10`,
      },
    ],
    describe: [
      {
        title: "Requête DESCRIBE simple",
        description: "Décrit une ressource spécifique",
        query: `PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

DESCRIBE ?s
WHERE {
  ?s rdfs:label ?label .
}
LIMIT 5`,
      },
      {
        title: "DESCRIBE avec URI directe",
        description: "Décrit une ressource spécifique par son URI",
        query: `DESCRIBE <http://dbpedia.org/resource/Paris>`,
      },
    ],
    update: [
      {
        title: "Requête INSERT DATA",
        description: "Ajoute de nouveaux triplets au graphe",
        query: `PREFIX ex: <http://example.org/>

INSERT DATA {
  ex:Resource1 ex:hasProperty "Value1" .
  ex:Resource2 ex:hasProperty "Value2" .
}`,
      },
      {
        title: "Requête DELETE DATA",
        description: "Supprime des triplets spécifiques du graphe",
        query: `PREFIX ex: <http://example.org/>

DELETE DATA {
  ex:Resource1 ex:hasProperty "Value1" .
}`,
      },
      {
        title: "Requête DELETE/INSERT",
        description: "Modifie des triplets existants",
        query: `PREFIX ex: <http://example.org/>

DELETE {
  ?s ex:hasProperty "OldValue" .
}
INSERT {
  ?s ex:hasProperty "NewValue" .
}
WHERE {
  ?s ex:hasProperty "OldValue" .
}`,
      },
    ],
  }

  return (
    <Card className="border border-slate-200 dark:border-slate-700 shadow-lg bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-2xl font-bold bg-semantic-gradient bg-clip-text text-transparent flex items-center">
          <HelpCircle className="h-6 w-6 mr-2 text-semantic-purple" />
          Documentation SPARQL
        </CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-300">
          Guide des différents types de requêtes SPARQL et exemples d'utilisation
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-4">
            <TabsTrigger value="select" className="flex items-center gap-1">
              <Search className="h-4 w-4" />
              SELECT
            </TabsTrigger>
            <TabsTrigger value="ask" className="flex items-center gap-1">
              <CheckCircle className="h-4 w-4" />
              ASK
            </TabsTrigger>
            <TabsTrigger value="construct" className="flex items-center gap-1">
              <Database className="h-4 w-4" />
              CONSTRUCT
            </TabsTrigger>
            <TabsTrigger value="describe" className="flex items-center gap-1">
              <FileText className="h-4 w-4" />
              DESCRIBE
            </TabsTrigger>
            <TabsTrigger value="update" className="flex items-center gap-1">
              <PenTool className="h-4 w-4" />
              UPDATE
            </TabsTrigger>
          </TabsList>

          <TabsContent value="select">
            <div className="space-y-4">
              <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                <h3 className="text-lg font-semibold mb-2">Requêtes SELECT</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                  Les requêtes SELECT permettent d'extraire des données spécifiques d'un graphe RDF. Elles retournent
                  une table de résultats avec des variables liées.
                </p>
                <Alert className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30 mt-2">
                  <AlertDescription className="text-sm">
                    <strong>Syntaxe de base:</strong>
                    <pre className="mt-1 p-2 bg-white dark:bg-slate-900 rounded text-xs overflow-x-auto">
                      {`SELECT ?variable1 ?variable2 ... 
WHERE { 
  ?subject ?predicate ?object . 
  # Autres patterns de triplets
}`}
                    </pre>
                  </AlertDescription>
                </Alert>
              </div>

              <ScrollArea className="h-[300px] rounded-lg border border-slate-200 dark:border-slate-700 p-4">
                <div className="space-y-4">
                  <h4 className="font-medium">Exemples de requêtes SELECT:</h4>
                  {examples.select.map((example, index) => (
                    <div
                      key={index}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h5 className="font-medium text-semantic-blue">{example.title}</h5>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{example.description}</p>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => copyToClipboard(example.query)}
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7"
                            onClick={() => onSelectExample(example.query)}
                          >
                            Utiliser
                          </Button>
                        </div>
                      </div>
                      <pre className="text-xs p-2 bg-slate-50 dark:bg-slate-900 rounded overflow-x-auto">
                        {example.query}
                      </pre>
                    </div>
                  ))}

                  <Accordion type="single" collapsible className="mt-4">
                    <AccordionItem value="advanced-select">
                      <AccordionTrigger className="text-sm font-medium">
                        Fonctionnalités avancées des requêtes SELECT
                      </AccordionTrigger>
                      <AccordionContent className="text-sm space-y-2">
                        <p>
                          <Badge className="mr-2 bg-semantic-purple">DISTINCT</Badge>
                          Élimine les doublons dans les résultats
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-blue">ORDER BY</Badge>
                          Trie les résultats selon une ou plusieurs variables
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-teal">GROUP BY</Badge>
                          Groupe les résultats selon une ou plusieurs variables
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-green">HAVING</Badge>
                          Filtre les groupes de résultats
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-orange">LIMIT</Badge>
                          Limite le nombre de résultats retournés
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-pink">OFFSET</Badge>
                          Saute un certain nombre de résultats (pagination)
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="ask">
            <div className="space-y-4">
              <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                <h3 className="text-lg font-semibold mb-2">Requêtes ASK</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                  Les requêtes ASK permettent de vérifier si un pattern de graphe existe dans les données. Elles
                  retournent un booléen (TRUE ou FALSE).
                </p>
                <Alert className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30 mt-2">
                  <AlertDescription className="text-sm">
                    <strong>Syntaxe de base:</strong>
                    <pre className="mt-1 p-2 bg-white dark:bg-slate-900 rounded text-xs overflow-x-auto">
                      {`ASK { 
  ?subject ?predicate ?object . 
  # Autres patterns de triplets
}`}
                    </pre>
                  </AlertDescription>
                </Alert>
              </div>

              <ScrollArea className="h-[300px] rounded-lg border border-slate-200 dark:border-slate-700 p-4">
                <div className="space-y-4">
                  <h4 className="font-medium">Exemples de requêtes ASK:</h4>
                  {examples.ask.map((example, index) => (
                    <div
                      key={index}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h5 className="font-medium text-semantic-blue">{example.title}</h5>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{example.description}</p>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => copyToClipboard(example.query)}
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7"
                            onClick={() => onSelectExample(example.query)}
                          >
                            Utiliser
                          </Button>
                        </div>
                      </div>
                      <pre className="text-xs p-2 bg-slate-50 dark:bg-slate-900 rounded overflow-x-auto">
                        {example.query}
                      </pre>
                    </div>
                  ))}

                  <Accordion type="single" collapsible className="mt-4">
                    <AccordionItem value="ask-usage">
                      <AccordionTrigger className="text-sm font-medium">
                        Cas d'utilisation des requêtes ASK
                      </AccordionTrigger>
                      <AccordionContent className="text-sm space-y-2">
                        <p>
                          <Badge className="mr-2 bg-semantic-purple">Validation</Badge>
                          Vérifier si certaines données existent avant de les traiter
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-blue">Contraintes</Badge>
                          Vérifier si les données respectent certaines contraintes
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-teal">Recherche</Badge>
                          Vérifier rapidement l'existence d'une information sans récupérer toutes les données
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="construct">
            <div className="space-y-4">
              <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                <h3 className="text-lg font-semibold mb-2">Requ��tes CONSTRUCT</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                  Les requêtes CONSTRUCT permettent de créer un nouveau graphe RDF à partir des données existantes.
                  Elles retournent un ensemble de triplets RDF.
                </p>
                <Alert className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30 mt-2">
                  <AlertDescription className="text-sm">
                    <strong>Syntaxe de base:</strong>
                    <pre className="mt-1 p-2 bg-white dark:bg-slate-900 rounded text-xs overflow-x-auto">
                      {`CONSTRUCT { 
  ?subject ?predicate ?object . 
  # Triplets à construire
}
WHERE { 
  ?subject ?predicate ?object . 
  # Patterns de recherche
}`}
                    </pre>
                  </AlertDescription>
                </Alert>
              </div>

              <ScrollArea className="h-[300px] rounded-lg border border-slate-200 dark:border-slate-700 p-4">
                <div className="space-y-4">
                  <h4 className="font-medium">Exemples de requêtes CONSTRUCT:</h4>
                  {examples.construct.map((example, index) => (
                    <div
                      key={index}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h5 className="font-medium text-semantic-blue">{example.title}</h5>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{example.description}</p>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => copyToClipboard(example.query)}
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7"
                            onClick={() => onSelectExample(example.query)}
                          >
                            Utiliser
                          </Button>
                        </div>
                      </div>
                      <pre className="text-xs p-2 bg-slate-50 dark:bg-slate-900 rounded overflow-x-auto">
                        {example.query}
                      </pre>
                    </div>
                  ))}

                  <Accordion type="single" collapsible className="mt-4">
                    <AccordionItem value="construct-usage">
                      <AccordionTrigger className="text-sm font-medium">
                        Avantages des requêtes CONSTRUCT
                      </AccordionTrigger>
                      <AccordionContent className="text-sm space-y-2">
                        <p>
                          <Badge className="mr-2 bg-semantic-purple">Transformation</Badge>
                          Transformer des données d'un schéma à un autre
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-blue">Intégration</Badge>
                          Créer des graphes RDF qui peuvent être intégrés à d'autres données
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-teal">Extraction</Badge>
                          Extraire un sous-graphe spécifique à partir d'un graphe plus large
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-green">Inférence</Badge>
                          Générer de nouvelles connaissances à partir des données existantes
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="describe">
            <div className="space-y-4">
              <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                <h3 className="text-lg font-semibold mb-2">Requêtes DESCRIBE</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                  Les requêtes DESCRIBE permettent d'obtenir une description RDF d'une ressource. Elles retournent un
                  ensemble de triplets RDF décrivant la ressource.
                </p>
                <Alert className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30 mt-2">
                  <AlertDescription className="text-sm">
                    <strong>Syntaxe de base:</strong>
                    <pre className="mt-1 p-2 bg-white dark:bg-slate-900 rounded text-xs overflow-x-auto">
                      {`DESCRIBE <uri> 
# ou
DESCRIBE ?variable
WHERE { 
  # Patterns pour trouver la variable
}`}
                    </pre>
                  </AlertDescription>
                </Alert>
              </div>

              <ScrollArea className="h-[300px] rounded-lg border border-slate-200 dark:border-slate-700 p-4">
                <div className="space-y-4">
                  <h4 className="font-medium">Exemples de requêtes DESCRIBE:</h4>
                  {examples.describe.map((example, index) => (
                    <div
                      key={index}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h5 className="font-medium text-semantic-blue">{example.title}</h5>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{example.description}</p>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => copyToClipboard(example.query)}
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7"
                            onClick={() => onSelectExample(example.query)}
                          >
                            Utiliser
                          </Button>
                        </div>
                      </div>
                      <pre className="text-xs p-2 bg-slate-50 dark:bg-slate-900 rounded overflow-x-auto">
                        {example.query}
                      </pre>
                    </div>
                  ))}

                  <Accordion type="single" collapsible className="mt-4">
                    <AccordionItem value="describe-info">
                      <AccordionTrigger className="text-sm font-medium">
                        Particularités des requêtes DESCRIBE
                      </AccordionTrigger>
                      <AccordionContent className="text-sm space-y-2">
                        <p>
                          <Badge className="mr-2 bg-semantic-purple">Implémentation dépendante</Badge>
                          Le contenu exact retourné par DESCRIBE peut varier selon l'implémentation du serveur SPARQL
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-blue">Concise Bounded Description</Badge>
                          Souvent, DESCRIBE retourne une "Concise Bounded Description" (CBD) de la ressource
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-teal">Exploration</Badge>
                          Idéal pour explorer des données RDF sans connaître leur structure à l'avance
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="update">
            <div className="space-y-4">
              <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                <h3 className="text-lg font-semibold mb-2">Requêtes UPDATE</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                  Les requêtes UPDATE permettent de modifier les données d'un graphe RDF. Elles incluent les opérations
                  INSERT et DELETE.
                </p>
                <Alert className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30 mt-2">
                  <AlertDescription className="text-sm">
                    <strong>Syntaxe de base:</strong>
                    <pre className="mt-1 p-2 bg-white dark:bg-slate-900 rounded text-xs overflow-x-auto">
                      {`# Insertion de données
INSERT DATA { 
  # Triplets à insérer
}

# Suppression de données
DELETE DATA { 
  # Triplets à supprimer
}

# Modification conditionnelle
DELETE { 
  # Triplets à supprimer
}
INSERT { 
  # Triplets à insérer
}
WHERE { 
  # Conditions
}`}
                    </pre>
                  </AlertDescription>
                </Alert>
              </div>

              <ScrollArea className="h-[300px] rounded-lg border border-slate-200 dark:border-slate-700 p-4">
                <div className="space-y-4">
                  <h4 className="font-medium">Exemples de requêtes UPDATE:</h4>
                  {examples.update.map((example, index) => (
                    <div
                      key={index}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h5 className="font-medium text-semantic-blue">{example.title}</h5>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{example.description}</p>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => copyToClipboard(example.query)}
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7"
                            onClick={() => onSelectExample(example.query)}
                          >
                            Utiliser
                          </Button>
                        </div>
                      </div>
                      <pre className="text-xs p-2 bg-slate-50 dark:bg-slate-900 rounded overflow-x-auto">
                        {example.query}
                      </pre>
                    </div>
                  ))}

                  <Accordion type="single" collapsible className="mt-4">
                    <AccordionItem value="update-warning">
                      <AccordionTrigger className="text-sm font-medium">
                        Remarques importantes sur les requêtes UPDATE
                      </AccordionTrigger>
                      <AccordionContent className="text-sm space-y-2">
                        <p>
                          <Badge className="mr-2 bg-semantic-pink">Attention</Badge>
                          Les requêtes UPDATE modifient les données et peuvent être irréversibles
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-orange">Permissions</Badge>
                          De nombreux endpoints SPARQL publics n'autorisent pas les requêtes UPDATE
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-purple">Graphes nommés</Badge>
                          Les requêtes UPDATE peuvent cibler des graphes spécifiques avec les clauses GRAPH
                        </p>
                        <p>
                          <Badge className="mr-2 bg-semantic-blue">Transactions</Badge>
                          Certains serveurs SPARQL supportent les transactions pour les opérations UPDATE
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              </ScrollArea>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
