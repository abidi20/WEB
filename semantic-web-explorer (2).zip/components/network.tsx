import { LucideNetwork } from "lucide-react"

export function Network(props) {
  return <LucideNetwork {...props} />
}
