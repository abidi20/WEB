"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useRdfStore } from "@/lib/rdf-store"
import { NodeDetails } from "@/components/node-details"
import { Search, Maximize2, Minimize2, RotateCcw } from "lucide-react"
import dynamic from "next/dynamic"

// Dynamically import ForceGraph3D with no SSR
const ForceGraph3D = dynamic(() => import("react-force-graph-3d"), { ssr: false })

export function GraphExplorer() {
  const { toast } = useToast()
  const { graph, selectedNode, setSelectedNode, getNodeCBD } = useRdfStore()
  const [searchTerm, setSearchTerm] = useState("")
  const [graphData, setGraphData] = useState({ nodes: [], links: [] })
  const [isFullscreen, setIsFullscreen] = useState(false)
  const graphRef = useRef()
  const [isGraphLoaded, setIsGraphLoaded] = useState(false)

  useEffect(() => {
    setIsGraphLoaded(true)
  }, [])

  useEffect(() => {
    if (graph) {
      // Convert RDF graph to format needed by ForceGraph
      const nodes = []
      const links = []

      // This is a simplified example - in a real app, you'd need to properly
      // extract nodes and links from your RDF store
      try {
        // Example conversion logic
        const nodeMap = new Map()

        graph.forEach((quad) => {
          if (!nodeMap.has(quad.subject.value)) {
            nodeMap.set(quad.subject.value, {
              id: quad.subject.value,
              name: quad.subject.value.split("/").pop() || quad.subject.value.split("#").pop() || quad.subject.value,
              val: 1,
              color: "#7209b7", // Updated color to match our theme
            })
          }

          if (!nodeMap.has(quad.object.value) && quad.object.termType === "NamedNode") {
            nodeMap.set(quad.object.value, {
              id: quad.object.value,
              name: quad.object.value.split("/").pop() || quad.object.value.split("#").pop() || quad.object.value,
              val: 1,
              color: "#4361ee", // Updated color to match our theme
            })
          }

          if (quad.object.termType === "NamedNode") {
            links.push({
              source: quad.subject.value,
              target: quad.object.value,
              predicate: quad.predicate.value,
              name:
                quad.predicate.value.split("/").pop() || quad.predicate.value.split("#").pop() || quad.predicate.value,
            })
          }
        })

        setGraphData({
          nodes: Array.from(nodeMap.values()),
          links: links,
        })
      } catch (error) {
        toast({
          title: "Error processing graph data",
          description: error.message,
          variant: "destructive",
        })
      }
    }
  }, [graph, toast])

  const handleNodeClick = (node) => {
    setSelectedNode(node.id)
    getNodeCBD(node.id)
  }

  const handleSearch = () => {
    if (!searchTerm) return

    try {
      // Find the node in the graph
      const node = graphData.nodes.find(
        (n) =>
          n.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
          n.name.toLowerCase().includes(searchTerm.toLowerCase()),
      )

      if (node) {
        setSelectedNode(node.id)
        getNodeCBD(node.id)

        // Center the graph on this node
        if (graphRef.current) {
          graphRef.current.centerAt(node.x, node.y, 1000)
          graphRef.current.zoom(2, 1000)
        }
      } else {
        toast({
          title: "Node not found",
          description: `No node matching "${searchTerm}" was found in the graph.`,
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Search error",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const resetCamera = () => {
    if (graphRef.current) {
      graphRef.current.zoomToFit(1000)
    }
  }

  return (
    <div className={`grid ${isFullscreen ? "grid-cols-1" : "grid-cols-1 md:grid-cols-3"} gap-6`}>
      <div className={`${isFullscreen ? "col-span-1" : "md:col-span-2"}`}>
        <Card className="h-[650px] border border-slate-200 dark:border-slate-700 shadow-lg bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-2xl font-bold bg-semantic-gradient bg-clip-text text-transparent">
                  Visualisation du Graphe RDF
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-300">
                  Explorez visuellement le graphe RDF. Cliquez sur les nœuds pour voir les détails.
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon" onClick={resetCamera} className="rounded-full h-8 w-8">
                  <RotateCcw className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={toggleFullscreen} className="rounded-full h-8 w-8">
                  {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Rechercher un nœud..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  className="pl-9 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                />
              </div>
              <Button onClick={handleSearch} className="bg-semantic-gradient hover:opacity-90 transition-opacity">
                Rechercher
              </Button>
            </div>
          </CardHeader>
          <CardContent className="h-[550px] pt-2">
            {graphData.nodes.length > 0 ? (
              <div className="h-full w-full rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700">
                {isGraphLoaded && (
                  <ForceGraph3D
                    ref={graphRef}
                    graphData={graphData}
                    nodeLabel="name"
                    linkLabel="name"
                    nodeColor="color"
                    onNodeClick={handleNodeClick}
                    linkDirectionalArrowLength={3.5}
                    linkDirectionalArrowRelPos={1}
                    linkCurvature={0.25}
                    backgroundColor="#ffffff"
                    linkColor={() => "#4cc9f0"}
                    linkWidth={1.5}
                    nodeRelSize={6}
                  />
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-dashed border-slate-300 dark:border-slate-600">
                <div className="w-16 h-16 mb-4 rounded-full bg-semantic-gradient flex items-center justify-center animate-pulse-slow">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-white"
                  >
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="2" y1="12" x2="22" y2="12"></line>
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                  </svg>
                </div>
                <p className="text-slate-600 dark:text-slate-300 text-center max-w-xs">
                  Aucune donnée de graphe chargée. Veuillez charger un fichier RDF ou vous connecter à un endpoint
                  SPARQL.
                </p>
                <Button
                  variant="link"
                  className="mt-4 text-semantic-blue dark:text-semantic-teal"
                  onClick={() => {
                    const loadTab = document.querySelector('[value="load"]')
                    if (loadTab) {
                      loadTab.click()
                    } else {
                      // Fallback si l'élément n'est pas trouvé
                      toast({
                        title: "Navigation",
                        description: "Veuillez aller à l'onglet 'Charger des Données' pour importer des données RDF.",
                      })
                    }
                  }}
                >
                  Charger des données
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {!isFullscreen && (
        <div>
          <NodeDetails />
        </div>
      )}
    </div>
  )
}
