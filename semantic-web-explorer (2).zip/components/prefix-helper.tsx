"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Copy, Check, Info, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function PrefixHelper({ onAddPrefix }) {
  const { toast } = useToast()
  const [copied, setCopied] = useState(null)

  const commonPrefixes = [
    {
      prefix: "rdf",
      uri: "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
      description: "Vocabulaire RDF de base",
      status: "stable",
    },
    {
      prefix: "rdfs",
      uri: "http://www.w3.org/2000/01/rdf-schema#",
      description: "Schéma RDF",
      status: "stable",
    },
    {
      prefix: "owl",
      uri: "http://www.w3.org/2002/07/owl#",
      description: "Web Ontology Language",
      status: "stable",
    },
    {
      prefix: "xsd",
      uri: "http://www.w3.org/2001/XMLSchema#",
      description: "Types de données XML Schema",
      status: "stable",
    },
    {
      prefix: "foaf",
      uri: "http://xmlns.com/foaf/0.1/",
      description: "Friend of a Friend (personnes et relations)",
      status: "warning",
    },
    {
      prefix: "dc",
      uri: "http://purl.org/dc/elements/1.1/",
      description: "Dublin Core (métadonnées)",
      status: "stable",
    },
    {
      prefix: "dcterms",
      uri: "http://purl.org/dc/terms/",
      description: "Dublin Core Terms",
      status: "stable",
    },
    {
      prefix: "skos",
      uri: "http://www.w3.org/2004/02/skos/core#",
      description: "Simple Knowledge Organization System",
      status: "stable",
    },
    {
      prefix: "schema",
      uri: "http://schema.org/",
      description: "Schema.org",
      status: "stable",
    },
    {
      prefix: "ex",
      uri: "http://example.org/",
      description: "Exemple (pour tests)",
      status: "warning",
    },
  ]

  const copyPrefix = (prefix) => {
    const prefixDeclaration = `PREFIX ${prefix.prefix}: <${prefix.uri}>\n`
    navigator.clipboard.writeText(prefixDeclaration).then(
      () => {
        setCopied(prefix.prefix)
        setTimeout(() => setCopied(null), 2000)
        toast({
          title: "Préfixe copié",
          description: `Le préfixe ${prefix.prefix} a été copié dans le presse-papiers.`,
        })
      },
      (err) => {
        toast({
          title: "Erreur",
          description: "Impossible de copier le préfixe: " + err,
          variant: "destructive",
        })
      },
    )
  }

  const addPrefix = (prefix) => {
    if (onAddPrefix) {
      onAddPrefix(`PREFIX ${prefix.prefix}: <${prefix.uri}>\n`)
      toast({
        title: "Préfixe ajouté",
        description: `Le préfixe ${prefix.prefix} a été ajouté à votre requête.`,
      })
    }
  }

  return (
    <Card className="border border-slate-200 dark:border-slate-700 shadow-lg bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl font-bold bg-semantic-gradient bg-clip-text text-transparent flex items-center">
          <Info className="h-5 w-5 mr-2 text-semantic-purple" />
          Préfixes SPARQL Courants
        </CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-300">
          Utilisez ces préfixes standards dans vos requêtes SPARQL
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Alert className="mb-4 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Les préfixes marqués d'un avertissement peuvent nécessiter des données locales pour fonctionner
            correctement. L'application fournit des définitions de base pour ces préfixes.
          </AlertDescription>
        </Alert>

        <ScrollArea className="h-[300px]">
          <div className="space-y-2">
            {commonPrefixes.map((prefix) => (
              <div
                key={prefix.prefix}
                className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex justify-between items-start"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-semantic-blue">{prefix.prefix}:</span>
                    {prefix.status === "warning" && <Badge className="bg-amber-500">Attention</Badge>}
                  </div>
                  <div className="font-mono text-xs text-slate-500 mt-1 break-all">{prefix.uri}</div>
                  <div className="text-xs mt-1">{prefix.description}</div>
                </div>
                <div className="flex gap-1">
                  <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => copyPrefix(prefix)}>
                    {copied === prefix.prefix ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  </Button>
                  <Button variant="outline" size="sm" className="h-7" onClick={() => addPrefix(prefix)}>
                    Ajouter
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter>
        <Button
          onClick={() => {
            const allPrefixes = commonPrefixes.map((p) => `PREFIX ${p.prefix}: <${p.uri}>`).join("\n")
            navigator.clipboard.writeText(allPrefixes + "\n\n")
            toast({
              title: "Tous les préfixes copiés",
              description: "Tous les préfixes ont été copiés dans le presse-papiers.",
            })
          }}
          className="w-full bg-semantic-gradient hover:opacity-90 transition-opacity"
        >
          Copier tous les préfixes
        </Button>
      </CardFooter>
    </Card>
  )
}
