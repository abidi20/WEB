"use client"

import { useState, useEffect, useRef } from "react"
import dynamic from "next/dynamic"
import { useBrowser } from "@/hooks/use-browser"
import { useRdfStore } from "@/lib/rdf-store"
import { Button } from "@/components/ui/button"
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react"

// Dynamically import ForceGraph2D with no SSR
const ForceGraph2D = dynamic(() => import("react-force-graph-2d"), { ssr: false })

export function NodeCbdView({ nodeId, onGraphDataUpdate }) {
  const { cbd } = useRdfStore()
  const [graphData, setGraphData] = useState({ nodes: [], links: [] })
  const isBrowser = useBrowser()
  const graphRef = useRef()
  const prevCbdRef = useRef(null)

  useEffect(() => {
    if (!isBrowser || !cbd || !nodeId) return

    // Vérifier si la CBD a changé pour éviter les traitements inutiles
    if (prevCbdRef.current === cbd) return
    prevCbdRef.current = cbd

    try {
      console.log("Processing CBD for visualization", cbd.length)

      // Convertir la CBD en format pour la visualisation
      const nodes = new Map()
      const links = []

      // Ajouter le nœud central
      nodes.set(nodeId, {
        id: nodeId,
        name: nodeId.split("/").pop() || nodeId.split("#").pop() || nodeId,
        color: "#7209b7", // Violet pour le nœud central
        size: 15,
      })

      // Parcourir tous les quads de la CBD
      cbd.forEach((quad) => {
        // Ajouter le nœud objet s'il n'existe pas déjà et si c'est une URI
        if (quad.object.termType === "NamedNode" && !nodes.has(quad.object.value)) {
          nodes.set(quad.object.value, {
            id: quad.object.value,
            name: quad.object.value.split("/").pop() || quad.object.value.split("#").pop() || quad.object.value,
            color: "#4361ee", // Bleu pour les objets
            size: 8,
          })
        } else if (quad.object.termType === "Literal" && !nodes.has(`lit_${quad.object.value}`)) {
          // Ajouter les littéraux avec un identifiant unique
          const litId = `lit_${quad.object.value}`
          nodes.set(litId, {
            id: litId,
            name: quad.object.value,
            color: "#f72585", // Rose pour les littéraux
            size: 6,
          })
        }

        // Ajouter un lien
        const targetId = quad.object.termType === "NamedNode" ? quad.object.value : `lit_${quad.object.value}`
        links.push({
          source: quad.subject.value,
          target: targetId,
          name: quad.predicate.value.split("/").pop() || quad.predicate.value.split("#").pop() || quad.predicate.value,
        })
      })

      console.log(`Created CBD graph visualization with ${nodes.size} nodes and ${links.length} links`)

      const newGraphData = {
        nodes: Array.from(nodes.values()),
        links: links,
      }

      // Mettre à jour l'état
      setGraphData(newGraphData)

      // Notifier le parent des données du graphe mises à jour
      if (onGraphDataUpdate) {
        onGraphDataUpdate(newGraphData)
      }
    } catch (error) {
      console.error("Error creating CBD graph visualization:", error)
      setGraphData({ nodes: [], links: [] })
      if (onGraphDataUpdate) {
        onGraphDataUpdate({ nodes: [], links: [] })
      }
    }
  }, [cbd, nodeId, isBrowser, onGraphDataUpdate])

  const handleZoomIn = () => {
    if (graphRef.current) {
      const currentZoom = graphRef.current.zoom()
      graphRef.current.zoom(currentZoom * 1.5, 400)
    }
  }

  const handleZoomOut = () => {
    if (graphRef.current) {
      const currentZoom = graphRef.current.zoom()
      graphRef.current.zoom(currentZoom / 1.5, 400)
    }
  }

  const handleReset = () => {
    if (graphRef.current) {
      graphRef.current.zoomToFit(400)
    }
  }

  if (!isBrowser || !cbd || cbd.length === 0 || graphData.nodes.length === 0) {
    return (
      <div className="flex items-center justify-center h-[400px] bg-slate-50 dark:bg-slate-800 rounded-lg border border-dashed">
        <p className="text-slate-500">Aucune donnée CBD à visualiser pour ce nœud.</p>
      </div>
    )
  }

  return (
    <div className="relative h-[400px] border rounded-lg overflow-hidden">
      <div className="absolute top-2 right-2 z-10 flex gap-1">
        <Button
          variant="outline"
          size="icon"
          onClick={handleZoomIn}
          className="bg-white/80 dark:bg-slate-800/80 h-8 w-8"
        >
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={handleZoomOut}
          className="bg-white/80 dark:bg-slate-800/80 h-8 w-8"
        >
          <ZoomOut className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={handleReset}
          className="bg-white/80 dark:bg-slate-800/80 h-8 w-8"
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>

      <div className="absolute bottom-2 left-2 z-10 bg-white/80 dark:bg-slate-800/80 px-2 py-1 rounded text-xs">
        {graphData.nodes.length} nœuds, {graphData.links.length} liens
      </div>

      <ForceGraph2D
        ref={graphRef}
        graphData={graphData}
        nodeLabel="name"
        linkLabel="name"
        nodeColor="color"
        nodeVal="size"
        linkDirectionalArrowLength={3}
        linkDirectionalArrowRelPos={1}
        backgroundColor="#ffffff"
        linkColor={() => "#4cc9f0"}
        onEngineStop={() => graphRef.current?.zoomToFit(400)}
      />
    </div>
  )
}
